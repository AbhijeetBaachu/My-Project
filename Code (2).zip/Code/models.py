from uuid import UUID
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import Column, Integer, String, Boolean, DateTime, ForeignKey, Float
from sqlalchemy.orm import relationship
from sqlalchemy.dialects.mssql import UNIQUEIDENTIFIER
from sqlalchemy.types import Enum as SQLAEnum
import uuid
from enum import Enum
from database import *

Base = declarative_base()

class MaterialTextStatus(Enum):
    SCHEDULED = "SCHEDULED"
    INPROGRESS = "INPROGRESS"
    CLEANSED = "CLEANSED"

class Class(Base):
    __tablename__ = 'Class'

    Class_Id = Column(String(64), primary_key=True, index=True)
    Class_Name = Column(String(256), index=True)
    Class_Short_Name = Column(String(48), index=True)
    Class_Status = Column(String(16), index=True)
    Created_By = Column(String(256), index=True)
    Created_On = Column(DateTime, index=True)
    Modified_By = Column(String(256), index=True)
    Modified_On = Column(DateTime, index=True)
    Family_Name = Column(String(64), index=True)

    # Relationship to taxonomy
    taxonomies = relationship("Taxonomy", back_populates="class_")

    # Relationship to allowable values
    allowableValues = relationship("AllowableValues", back_populates="class_")

    # Relationship to MaterialText
    materialtext = relationship("MaterialText", back_populates="class_")

    # Relationship to class result
    predicted_results = relationship("ClassResult", foreign_keys="ClassResult.Class_Predicted_Id", back_populates="predicted_class")
    proposed_results = relationship("ClassResult", foreign_keys="ClassResult.Proposed_Class_Id", back_populates="proposed_class")

    # Relationship to Cleansed Data
    cleanseddata = relationship("CleansedData", back_populates="class_")

class Users(Base):
    __tablename__ = 'Users'

    User_Id = Column(UNIQUEIDENTIFIER, primary_key=True, index=True, default=uuid.uuid4)
    # User_Name = Column(String(256), index=True) 
    FirstName = Column(String(256), index=True)
    LastName = Column(String(256), index=True)
    EmailId = Column(String(256), index=True)
    Role_Id = Column(UNIQUEIDENTIFIER, ForeignKey('Role.Role_Id'), index=True)
    Password = Column(String(256), index=True) 
    Status = Column(String(256), index=True) 
    Created_By = Column(String(256), index=True)
    Created_On = Column(DateTime, index=True)
    Modified_By = Column(String(256), index=True)
    Modified_On = Column(DateTime, index=True)

    role = relationship("Role", back_populates="user")

class Role(Base):
    __tablename__ = 'Role'

    Role_Id = Column(UNIQUEIDENTIFIER, primary_key=True, index=True, default=uuid.uuid4)
    Role_Name = Column(String(256), index=True)
    Status = Column(String(256), index=True) 
    Created_By = Column(String(256), index=True)
    Created_On = Column(DateTime, index=True)
    Modified_By = Column(String(256), index=True)
    Modified_On = Column(DateTime, index=True)

    user = relationship("Users", back_populates="role")

class Taxonomy(Base):
    __tablename__ = 'Taxonomy'

    Taxonomy_Id = Column(UNIQUEIDENTIFIER, primary_key=True, index=True)
    Family_Name = Column(String(64), index=True)
    Class_Id = Column(String(64), ForeignKey('Class.Class_Id'), index=True)
    Characteristic_Name = Column(String(1024), index=True)
    Importance = Column(Integer, index=True)
    ST_Sequence = Column(Integer, index=True)
    Is_Definite = Column(Boolean, default=False)
    Status = Column(String(16), index=True)
    Created_By = Column(String(256), index=True)
    Created_On = Column(DateTime, index=True)
    Modified_By = Column(String(256), index=True)
    Modified_On = Column(DateTime, index=True)

    # Relationship to class
    class_ = relationship("Class", back_populates="taxonomies")

class AllowableValues(Base):
    __tablename__ = 'AllowableValue'

    Av_Id = Column(UNIQUEIDENTIFIER, primary_key=True, index=True)
    Family_Name = Column(String(64), index=True)
    Class_Id = Column(String(64), ForeignKey('Class.Class_Id'), index=True)
    Chars_Name = Column(String(1024), index=True)
    Allowable_Value = Column(String, index=True)
    Av_Sequence = Column(Integer, index=True)
    Status = Column(String(16), index=True)
    Created_By = Column(String(256), index=True)
    Created_On = Column(DateTime, index=True)
    Modified_By = Column(String(256), index=True)
    Modified_On = Column(DateTime, index=True)

    # Relationship to class
    class_ = relationship("Class", back_populates="allowableValues")

class MaterialText(Base):
    __tablename__ = "MaterialText"

    MT_Id = Column(UNIQUEIDENTIFIER, primary_key=True, index=True)
    Family_Name = Column(String(64), index=True)
    System_Id = Column(String(128), index=True)
    MM_Id = Column(String(64), index=True)
    Long_Text = Column(String, index=True)
    Short_Text = Column(String, index=True)
    Status = Column(String, index=True)
    Created_By = Column(String(100), index=True)
    Created_On = Column(DateTime, index=True)
    Modified_By = Column(String(100), index=True)
    Modified_On = Column(DateTime, index=True)
    Class_Id = Column(String(64), ForeignKey('Class.Class_Id'), index=True)
    SCH_Id = Column(UNIQUEIDENTIFIER, ForeignKey('ScheduledCleansingHistory.SCH_Id'), index=True)

    # Relationship to ScheduleCleansing
    schcleansing = relationship("ScheduledCleansingHistory", back_populates="materialtext")

    # Relationship to class
    class_ = relationship("Class", back_populates="materialtext")

    # Relationship to cleanseddata
    cleanseddata = relationship("CleansedData", back_populates="materialtext")
    
class CleansedData(Base):
    __tablename__ = "CleansedData"

    CD_Id = Column(UNIQUEIDENTIFIER, primary_key=True, index=True)
    Family_Name = Column(String(64), index=True)
    MM_Id = Column(String(64), ForeignKey('MaterialText.MT_Id'), index=True)
    Sequence_No = Column(Integer, index=True)
    Characteristic_name = Column(String(1024), index=True)
    Current_Value = Column(String, index=True)
    Proposed_Value = Column(String, index=True)
    Suggested_Value = Column(String, index=True)
    Auto_Review = Column(String(16), index=True)
    Status = Column(String, index=True)
    Created_By = Column(String(256), index=True)
    Created_On = Column(DateTime, index=True)
    Modified_By = Column(String(256), index=True)
    Modified_On = Column(DateTime, index=True)
    Class_Id = Column(String(64), ForeignKey('Class.Class_Id'), index=True)
    Importance = Column(Integer, index=True)

    # Relationship to materialtext
    materialtext = relationship("MaterialText", back_populates="cleanseddata")

    # Relationship to class
    class_ = relationship("Class", back_populates="cleanseddata")

class ClassResult(Base):
    __tablename__ = "ClassResult"

    CR_Id = Column(UNIQUEIDENTIFIER, primary_key=True, index=True)
    MM_Id = Column(String(64), index=True)
    Lang = Column(String(128), index=True)
    Class_Predicted_Id = Column(String(64), ForeignKey('Class.Class_Id'), index=True)
    Probabilty = Column(Float, index=True)
    Proposed_Class_Id = Column(String(64), ForeignKey('Class.Class_Id'), index=True)
    Class_Review_Status = Column(String(50), index=True)
    Cleanse_Status = Column(String(50), index=True)
    Created_By = Column(String(256), index=True)
    Created_On = Column(DateTime, index=True)
    Modified_By = Column(String(256), index=True)
    Modified_On = Column(DateTime, index=True)

    # Relationship to class
    # class_ = relationship("Class", back_populates="classresult")
    predicted_class = relationship("Class", foreign_keys=[Class_Predicted_Id], back_populates="predicted_results")
    proposed_class = relationship("Class", foreign_keys=[Proposed_Class_Id], back_populates="proposed_results")

class ShortLongText(Base):
    __tablename__ = "ShortLongText"

    SLT_Id = Column(UNIQUEIDENTIFIER, primary_key=True, index=True)
    Family_Name = Column(String(64), index=True)
    MM_Id = Column(String(64), index=True)
    Proposed_Long_Text = Column(String, index=True)
    Propsed_Short_Text = Column(String(256), index=True)
    Review_Status = Column(String(16), index=True)
    Created_By = Column(String(256), index=True)
    Created_On = Column(DateTime, index=True)
    Modified_By = Column(String(256), index=True)
    Modified_On = Column(DateTime, index=True)

class ScheduledCleansingHistory(Base):
    __tablename__ = "ScheduledCleansingHistory"

    SCH_Id = Column(UNIQUEIDENTIFIER, primary_key=True, index=True, default=uuid.uuid4)
    Family_Name = Column(String(64), index=True)
    File_Path = Column(String(2048), index=True)
    Scheduled_Time = Column(DateTime, index=True)
    Scheduled_Status = Column(SQLAEnum(MaterialTextStatus), index=True)
    Created_By = Column(String(256), index=True)
    Created_On = Column(DateTime, index=True)
    Modified_By = Column(String(256), index=True)
    Modified_On = Column(DateTime, index=True)
    Scheduled_Progress = Column(Float, index=True)

    # Relationship to MaterialText
    materialtext = relationship("MaterialText", back_populates="schcleansing")





# Create tables
# Base.metadata.create_all(bind=engine)

# FastAPI instance
# app = FastAPI()

# Dependency to get a database session
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

def getdb():
    db = SessionLocal()
    connection = db.connection()
    cursor = connection.connection.cursor()
    try:
        yield db, cursor
    finally:
        db.close()
        cursor.close()


