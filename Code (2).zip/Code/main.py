#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Jun 24 10:15:05 2024

@author: 1041929, 1056026
"""

import pickle
import os
from textblob import TextBlob
from cleantext import clean
from sklearn.metrics.pairwise import linear_kernel
# import streamlit as st
from openai import AzureOpenAI
import json
import random
import pandas as pd
import re
import math
#from sklearn.metrics import classification_report
#import seaborn as sns
#import matplotlib.pyplot as plt
#from langdetect import detect 
import altair as alt
from PIL import Image
from llama_cpp import Llama
from chromadb import Documents, EmbeddingFunction, Embeddings
import chromadb
# import ast
from thefuzz import fuzz
from post_processing_tool import post_process, is_valve_component, st_text_generate, ltTextGenerated, get_missing_data
import uvicorn
from fastapi import FastAPI, Depends, HTTPException, UploadFile, File, Form, Query
from sqlalchemy.orm import sessionmaker, Session, relationship, joinedload
from fastapi.responses import JSONResponse
from models import *
# from lingua import Language, LanguageDetectorBuilder
from fastapi.middleware.cors import CORSMiddleware
from typing import List, Tuple, Union
from datetime import datetime, timedelta
from pyodbc import Cursor
import schedule
import time
import threading
from sqlalchemy import case
import pytz
import numpy as np
from sqlalchemy.exc import IntegrityError
from passlib.context import CryptContext

def checkScheduleTime():

    db = next(get_db())
    try:
        current_time = datetime.now()
        print("Task:", current_time)
        query = "SELECT * FROM ScheduledCleansingHistory where Scheduled_Status = 'SCHEDULED' and Scheduled_Time <= ?"
        params = (current_time + timedelta(minutes=1),)
        scheduledtasks = pd.read_sql(query, db.bind, params=params)
        print("scheduledtasks", scheduledtasks)

        for task in scheduledtasks.itertuples(index=False):
            familyName = task.Family_Name
            scheduledTime = task.Scheduled_Time
            sch_Id = task.SCH_Id

            if scheduledTime <= current_time < scheduledTime + timedelta(minutes=1):
                # cleanseData(family, generated_sch_id, db)
                threading.Thread(target=cleanseData, args = (familyName, sch_Id, db), daemon=True).start()
    except Exception as e:
        print(e)
        db.rollback()


def scheduleTask():
    schedule.every(1).minutes.do(checkScheduleTime)

    while True:
        schedule.run_pending()
        time.sleep(1)

threading.Thread(target=scheduleTask, daemon=True).start()

app = FastAPI()
urllist = ["http://localhost:5000",
        "http://localhost:8000",
        "https://localhost:5000"
]
app.add_middleware(
  CORSMiddleware,
  allow_origins = ["*"],
  allow_methods = ["*"],
  allow_headers = ["*"]
)


MODEL_PATH="../Models/"
INPUT_FOLDER="../Input/"
RESULTS_PATH="Results/"
TAXONOMY_PATH="../Taxonomy"
#GT_DATA="Project/Input/gt_data.csv"
#GT_COMPARE=True
# quest_logo=Image.open("images/Quest_Global_New_Logo.jpg")
# ledger_img=Image.open("images/ledger.png")
allow_values_size=5
sample_row_size=1000
familyname = "VALVES/ACTUATORS/OPERATORS"

with open(os.path.join(TAXONOMY_PATH,'char_data.json'),'r') as allow:
    all_allowables=json.load(allow)

CHAR_ALIASES={
    "GEMS_ID_MME":["GEMS ID","GEMS SPEC","GEMS CODE", "VALVE CODE"]
    }

CHARS_WITHOUT_STD=["MATERIAL_MME","SIZE_MME","PRESSURE_RATING_MME",'MANUFACTURER_PART_NUMBER_MME','ADDITIONAL_INFORMATION_MME','MANUFACTURER_NAME_MME']


importanceDict = {
    1: '1-Mandatory',
    2: '2-Optional',
    3: '3-Not Used'
}
# languages = [Language.ENGLISH, Language.FRENCH, Language.GERMAN]

# detector = LanguageDetectorBuilder.from_languages(*languages).build()

def is_non_english_tokens_present(text):
    for nw in NON_ENGLISH_WORDS:
        matches=re.findall(rf'(?i)\b{re.escape(nw)}\b',text)
        if matches:
            return True
    return False

def get_lang(text):
    text=re.sub(r'\s+',' ',text)
    
    if is_non_english_tokens_present(text):
        return 'NON-ENGLISH'
    
    text=text.upper()
        
    x_test = lang_tfidf_model.transform([text])
    x_test = lang_selector_model.transform(x_test).astype('float32')
    preds = lang_classification_model.predict(x_test) #Returns list 
    
    return preds[0]

# FINITE_VALUE_CHAR = [
#     ('ACTUATOR:ELECTRIC', 'FAIL_SAFE_OPERATION_MME'),
#     ('ACTUATOR:ELECTRIC', 'FREQUENCY_MME'),
#     ('ACTUATOR:ELECTRIC', 'INDUSTRY_STANDARD_MME'),
#     ('ACTUATOR:ELECTRIC', 'PHASE_MME'),
#     ('ACTUATOR:ELECTRIC', 'ROTATION_ANGLE_MME'),
#     ('ACTUATOR:ELECTRIC', 'TRAVEL_MME'),
#     ('ACTUATOR:NON-ELECTRIC', 'INDUSTRY_STANDARD_MME'),
#     ('COMPONENT:ACTUATOR', 'DRAWING_ITEM_NUMBER_MME'),
#     ('COMPONENT:ACTUATOR', 'FOR_VALVE_TYPE_MME'),
#     ('COMPONENT:VALVE', 'FLOW_RATING_MME'),
#     ('MANIFOLD:VALVE INSTRUMENT', 'END_CONNECTION_TYPE_MME'),
#     ('MANIFOLD:VALVE INSTRUMENT', 'INDUSTRY_STANDARD_MME'),
#     ('PLUG:VALVE', 'APPLICATION_MME'),
#     ('VALVE', 'API_TRIM_NUMBER_MME'),
#     ('VALVE', 'DESIGN_SPECIFICATION_MME'),
#     ('VALVE', 'FIRE_RATED_MME'),
#     ('VALVE', 'GEMS_ID_MME'),
#     ('VALVE', 'MATERIAL_MME'),
#     ('VALVE', 'OPERATOR_MME'),
#     ('VALVE:ANGLE', 'END_CONNECTION_TYPE_MME'),
#     ('VALVE:ANGLE', 'MATERIAL_MME'),
#     ('VALVE:ANGLE', 'TRIM_MATERIAL_MME'),
#     ('VALVE:BALL', 'BALL_TYPE_MME'),
#     ('VALVE:BALL', 'DESIGN_SPECIFICATION_MME'),
#     ('VALVE:BALL', 'FIRE_RATED_MME'),
#     ('VALVE:BALL', 'OPERATOR_MME'),
#     ('VALVE:BALL', 'PORT_TYPE_MME'),
#     ('VALVE:BLEED', 'END_CONNECTION_STANDARD_MME'),
#     ('VALVE:BLEED', 'END_CONNECTION_TYPE_MME'),
#     ('VALVE:BLEED', 'FIRE_RATED_MME'),
#     ('VALVE:BLEED', 'OPERATOR_MME'),
#     ('VALVE:BLEED', 'PORT_TYPE_MME'),
#     ('VALVE:BLEED', 'STEM_TYPE_MME'),
#     ('VALVE:BUTTERFLY', 'BUTTERFLY_TYPE_MME'),
#     ('VALVE:BUTTERFLY', 'DESIGN_SPECIFICATION_MME'),
#     ('VALVE:BUTTERFLY', 'END_CONNECTION_TYPE_MME'),
#     ('VALVE:BUTTERFLY', 'FIRE_RATED_MME'),
#     ('VALVE:BUTTERFLY', 'GEMS_ID_MME'),
#     ('VALVE:BUTTERFLY', 'OPERATOR_MME'),
#     ('VALVE:CHECK', 'API_TRIM_NUMBER_MME'),
#     ('VALVE:CHECK', 'BODY_CLOSURE_DESIGN_MME'),
#     ('VALVE:CHECK', 'CHECK_TYPE_MME'),
#     ('VALVE:CHECK', 'DESIGN_SPECIFICATION_MME'),
#     ('VALVE:CHECK', 'FIRE_RATED_MME'),
#     ('VALVE:CHECK', 'PORT_TYPE_MME'),
#     ('VALVE:CHOKE', 'END_CONNECTION_STANDARD_MME'),
#     ('VALVE:CHOKE', 'END_CONNECTION_TYPE_MME'),
#     ('VALVE:CHOKE', 'FIRE_RATED_MME'),
#     ('VALVE:CHOKE', 'MANUFACTURER_NAME_MME'),
#     ('VALVE:CHOKE', 'OPERATOR_MME'),
#     ('VALVE:CHOKE', 'STEM_TYPE_MME'),
#     ('VALVE:CONTROL', 'ACTUATOR_TYPE_MME'),
#     ('VALVE:CONTROL', 'API_TRIM_NUMBER_MME'),
#     ('VALVE:CONTROL', 'APPLICATION_MME'),
#     ('VALVE:CONTROL', 'CONFIGURATION_MME'),
#     ('VALVE:CONTROL', 'END_CONNECTION_STANDARD_MME'),
#     ('VALVE:CONTROL', 'STEM_TYPE_MME'),
#     ('VALVE:DIAPHRAGM', 'API_TRIM_NUMBER_MME'),
#     ('VALVE:DIAPHRAGM', 'END_CONNECTION_STANDARD_MME'),
#     ('VALVE:DIAPHRAGM', 'END_CONNECTION_TYPE_MME'),
#     ('VALVE:DIAPHRAGM', 'OPERATOR_MME'),
#     ('VALVE:DIAPHRAGM', 'PORT_TYPE_MME'),
#     ('VALVE:DRAIN', 'END_CONNECTION_TYPE_MME'),
#     ('VALVE:DRAIN', 'GEMS_ID_MME'),
#     ('VALVE:DRAIN', 'MATERIAL_MME'),
#     ('VALVE:GATE', 'API_TRIM_NUMBER_MME'),
#     ('VALVE:GATE', 'BODY_BONNET_CONNECTION_MME'),
#     ('VALVE:GATE', 'DESIGN_SPECIFICATION_MME'),
#     ('VALVE:GATE', 'OPERATOR_MME'),
#     ('VALVE:GATE', 'PORT_TYPE_MME'),
#     ('VALVE:GATE', 'STEM_TYPE_MME'),
#     ('VALVE:GLOBE', 'API_TRIM_NUMBER_MME'),
#     ('VALVE:GLOBE', 'BODY_BONNET_CONNECTION_MME'),
#     ('VALVE:GLOBE', 'DESIGN_SPECIFICATION_MME'),
#     ('VALVE:GLOBE', 'OPERATOR_MME'),
#     ('VALVE:GLOBE', 'PORT_TYPE_MME'),
#     ('VALVE:NEEDLE', 'BODY_BONNET_CONNECTION_MME'),
#     ('VALVE:NEEDLE', 'BODY_CLOSURE_DESIGN_MME'),
#     ('VALVE:NEEDLE', 'END_CONNECTION_STANDARD_MME'),
#     ('VALVE:NEEDLE', 'OPERATOR_MME'),
#     ('VALVE:NEEDLE', 'PORT_TYPE_MME'),
#     ('VALVE:PINCH', 'END_CONNECTION_TYPE_MME'),
#     ('VALVE:PINCH', 'MANUFACTURER_NAME_MME'),
#     ('VALVE:PINCH', 'MANUFACTURER_PART_NUMBER_MME'),
#     ('VALVE:PINCH', 'OPERATOR_MME'),
#     ('VALVE:PLUG', 'BODY_BONNET_CONNECTION_MME'),
#     ('VALVE:PLUG', 'BODY_CLOSURE_DESIGN_MME'),
#     ('VALVE:PLUG', 'BODY_MATERIAL_STANDARD_MME'),
#     ('VALVE:PLUG', 'END_CONNECTION_STANDARD_MME'),
#     ('VALVE:PLUG', 'END_CONNECTION_TYPE_MME'),
#     ('VALVE:PLUG', 'FIRE_RATED_MME'),
#     ('VALVE:PLUG', 'GEMS_ID_MME'),
#     ('VALVE:PLUG', 'OPERATOR_MME'),
#     ('VALVE:PLUG', 'PORT_TYPE_MME'),
#     ('VALVE:PLUG', 'SEAT_TYPE_MME'),
#     ('VALVE:PLUG', 'STEM_TYPE_MME'),
#     ('VALVE:PNEUMATIC', 'CONFIGURATION_MME'),
#     ('VALVE:PNEUMATIC', 'END_CONNECTION_TYPE_MME'),
#     ('VALVE:REGULATOR', 'MANUFACTURER_NAME_MME'),
#     ('VALVE:REGULATOR', 'MANUFACTURER_PART_NUMBER_MME'),
#     ('VALVE:SOLENOID', 'END_CONNECTION_STANDARD_MME'),
#     ('VALVE:SOLENOID', 'END_CONNECTION_TYPE_MME'),
#     ('VALVE:SOLENOID', 'FREQUENCY_MME')
# ]

    
NON_ENGLISH_WORDS=['é',
'materiaal', 
'MATIERE',
'BAGUE',
'Distributeur', 
'Â',
'Ã',
'SIEGE',
'VANNE',
'emetteur',
'RICAMBI', 
'DISTRIBUTEUR',
'CONNECTEUR',
'COMMANDE',
'ACTIONNEUR',
'VALVOLE',
'EXTREMITES',
'DIAMETRE',
'FEMELLE',
'PNEUMATIQUE',
'FONTE',
'SUPERIORE',
'INFERIORE',
'Pompe']

cleanse_system_prompt="""You will be provided a material information, your task is to do cleansing for Mechanical and Materials Engineering (MME), material cleansing is a process of identifying right values for material properties described in tools.
- Understand property values from given examples and give most appropriate ones
- Do not miss values for properties
- Make sure all property values must from given input text
- You must always use function calling
"""

with open(os.path.join(TAXONOMY_PATH,'std_data.json'),'r') as stddata:
    standardization_data=json.load(stddata)

# chroma_client = chromadb.HttpClient(host="localhost",port="3030")
# client = chromadb.HttpClient(
#     host="localhost",
#     port=3030,
#     ssl=False,
#     headers=None,
# )

# llm_emb_model = Llama(model_path='Models/nomic-embed-text-v1.5.Q4_0.gguf', embedding=True, verbose=False)

# def get_embfedding(text):
#     emb=llm_emb_model.create_embedding(text)
#     return emb['data'][0]['embedding']

# class CustomEmbeddingFunction(EmbeddingFunction):
#     def __call__(self, texts: Documents) -> Embeddings:
#         return list(map(get_embedding, texts))

# collection = chroma_client.get_or_create_collection("std_rules",embedding_function=CustomEmbeddingFunction(),metadata={"hnsw:space": "cosine"})

taxonomy_dict = {}
char_seq_dict = {}
allow_values_dict = {}
taxonomyClassCharImp_dict = {}

# print("taxonomy_dict", taxonomy_dict)

def read_allowableValues(familyName: str, material_class: str, db):
    global allow_values_dict

    db_allowableValues = db.query(AllowableValues).join(Class).filter(AllowableValues.Family_Name == familyName, Class.Class_Name == material_class)
    
    allow_values = pd.DataFrame([
        {
            **av.__dict__,
            'CLASS': av.class_.Class_Name if av.class_ else None
        }
        for av in db_allowableValues
    ])

    allow_values_groups=allow_values[['Chars_Name','Allowable_Value']].groupby(['Chars_Name'])

    allow_values_dict={}
    for g, df in allow_values_groups:
        values=df['Allowable_Value'].tolist()
        allow_values_dict[g]=values

    allow_values_dict = allow_values_dict

def read_taxonomy(familyName: str, db):
    global taxonomy_dict
    global char_seq_dict
    global taxonomyClassCharImp_dict
    # global allow_values_dict

    # print(taxonomy_dict)

    db_taxonomy = db.query(Taxonomy).filter_by(Family_Name = familyName)
    # db_allowableValues = db.query(AllowableValues).filter_by(Family_Name = familyName)

    # taxonomy_data=pd.read_excel(TAXONOMY_PATH,"Taxonomy")
    taxonomy_data=pd.DataFrame([
        {
            **t.__dict__,
            'CLASS': t.class_.Class_Name if t.class_ else None
        } 
        for t in db_taxonomy
    ])
    # print(taxonomy_data)

    # taxonomy_data=taxonomy_data.sort_values(by=['CLASS','SEQ NO.'])
    taxonomy_data=taxonomy_data.sort_values(by=['CLASS','ST_Sequence'])

    # allow_values=pd.read_excel(TAXONOMY_PATH,"Allowable_Values")
    # allow_values = pd.DataFrame([
    #     {
    #         **av.__dict__,
    #         'CLASS': av.class_.Class_Name if av.class_ else None
    #     }
    #     for av in db_allowableValues
    # ])

    # taxonomy_data=taxonomy_data[taxonomy_data['CHARS']!='ADDITIONAL_DETAIL'].copy()
    # taxonomy_data=taxonomy_data[taxonomy_data['Characteristic_Name']!='ADDITIONAL_DETAIL'].copy()
    taxonomy_data=taxonomy_data[~(taxonomy_data['Characteristic_Name'].str.contains('ADDITIONAL_DETAIL'))&(taxonomy_data['Characteristic_Name'].str.contains('MME'))].copy()
    taxonomy_mand=taxonomy_data.copy()

    taxonomyClassCharImp_group = taxonomy_mand[['Class_Id','Characteristic_Name','Importance']].groupby(['Class_Id', 'Characteristic_Name'])
    taxonomyClassCharImp_dict = {}
    for g, sub_df in taxonomyClassCharImp_group:
        for indx, row in sub_df.iterrows():
            importance_value = row['Importance']
            taxonomyClassCharImp_dict[g] = importance_value
            # taxonomyClassCharImp_dict[g] = int(row['Importance'])
    # taxonomy_groups=taxonomy_mand[['CLASS','CHARS','IS_MANDATORY']].groupby('CLASS')
    # chars_sq_groups=taxonomy_mand[['CLASS','CHARS','SEQ NO.']].groupby(['CLASS','CHARS'])

    taxonomy_groups=taxonomy_mand[['CLASS','Characteristic_Name','Importance']].groupby('CLASS')
    chars_sq_groups=taxonomy_mand[['CLASS','Characteristic_Name','ST_Sequence']].groupby(['CLASS','Characteristic_Name'])

    # taxonomy_dict={g:[(row['CHARS'],row['IS_MANDATORY']) for indx,row in df.iterrows()] for g,df in taxonomy_groups}
    taxonomy_dict={g:[(row['Characteristic_Name'],row['Importance']) for indx,row in df.iterrows()] for g,df in taxonomy_groups}

    # allow_values_groups=allow_values[['CLASS','CHAR','CHAR VALUES']].groupby(['CLASS','CHAR'])
    # allow_values_groups=allow_values[['CLASS','Chars_Name','Allowable_Value']].groupby(['CLASS','Chars_Name'])

    # allow_values_dict={}
    # for g, df in allow_values_groups:
    #     # values=df['CHAR VALUES'].tolist()
    #     values=df['Allowable_Value'].tolist()
    #     allow_values_dict[tuple(g)]=values
            
            
    char_seq_dict={}
    for g, df in chars_sq_groups:
        char_seq_dict[tuple(g)]=df['ST_Sequence'].tolist()[0]

    taxonomy_dict = taxonomy_dict
    char_seq_dict = char_seq_dict
    taxonomyClassCharImp_dict = taxonomyClassCharImp_dict
    # allow_values_dict = allow_values_dict
    # return taxonomy_dict, char_seq_dict, allow_values_dict

# Load config values
with open(r'config.json') as config_file:
    config_details = json.load(config_file)
    
# Intializing Azure OpenAI
client = AzureOpenAI(
    api_key=config_details.get("AZURE_OPENAI_API_KEY"),  
    api_version="2024-05-01-preview",
    azure_endpoint = config_details.get("AZURE_OPENAI_ENDPOINT")
    )

# NEGATIVE_CHAR_VALUES={
#     ('VALVE:PRESSURE SAFETY',	'PRESSURE_RATING_MME') : ['PN40'],
#     ('COMPONENT:ACTUATOR',	'MATERIAL_MME') : ['RING'],
#     ('VALVE:BALL', 'END_CONNECTION_TYPE_MME') : ['END ENTRY', 'FIF38085634', 'FIF'],
#     ('VALVE:BALL',	'GEMS_ID_MME') : ['L/O065401', 'FIF38085300', '743840'],
#     ('VALVE:BALL',	'PRESSURE_RATING_MME') : ['PN 101718'],
#     ('VALVE:BUTTERFLY', 'END_CONNECTION_TYPE_MME') : ['FIF92150512'],
#     ('VALVE:CHECK', 'GEMS_ID_MME') : ['19002000000000'],
#     ('VALVE:CHECK', 'DESIGN_SPECIFICATION_MME') : ['APPLIES'],
#     ('VALVE:CONTROL', 'API_TRIM_NUMBER_MME') : ['EQ', '316SS/stellited']
# }

FIXED_VALUE_CHARS = ['ACTUATOR_TYPE_MME', 
                       'API_TRIM_NUMBER_MME', 
                       'APPLICATION_MME', 
                       'BALL_TYPE_MME', 
                       'BODY_BONNET_CONNECTION_MME', 
                       'BODY_CLOSURE_DESIGN_MME', 
                       'BODY_MATERIAL_STANDARD_MME', 
                       'BUTTERFLY_TYPE_MME', 
                       'CURRENT_RATING_MME', 
                       'CHECK_TYPE_MME', 
                       'CONFIGURATION_MME', 
                       'DRAWING_ITEM_NUMBER_MME', 
                       'DRAWING_NUMBER_MME', 
                       'DESIGN_SPECIFICATION_MME', 
                       'ENCLOSURE_TYPE_MME', 
                       'END_CONNECTION_TYPE_MME', 
                       'END_CONNECTION_STANDARD_MME', 
                       'EQUIPMENT_MME', 
                       'EQUIPMENT_MODEL_NUMBER_MME', 
                       'EQUIPMENT_SERIAL_NUMBER_MME', 
                       'FAIL_SAFE_OPERATION_MME', 
                       'FIRE_RATED_MME', 
                       'FLOW_COEFFICIENT_MME', 
                       'FLOW_RATING_MME', 
                       'FOR_VALVE_TYPE_MME', 
                       'FREQUENCY_MME', 
                       'GEMS_ID_MME', 
                       'INDUSTRY_STANDARD_MME', 
                       'INTERNAL_SPEC_REF_MME', 
                       'LENGTH_MME', 
                       'MATERIAL_MME', 
                       'MANUFACTURER_NAME_MME', 
                       'MANUFACTURER_PART_NUMBER_MME', 
                       'MOUNTING_TYPE_MME', 
                       'MODEL_DESIGNATION_MME', 
                       'OBTUATOR_MATERIAL_MME', 
                       'OPERATOR_MME', 
                       'ORIFICE_SIZE_MME', 
                       'PARENT_FIGURE_MODEL_NUMBER_MME', 
                       'PHASE_MME', 
                       'POWER_RATING_MME', 
                       'PORT_TYPE_MME', 
                       'PROCESS_CONNECTION_MME', 
                       'RATING_MME', 
                       'ROTATION_ANGLE_MME', 
                       'SEAT_RING_MATERIAL_MME', 
                       'SEAT_SPRING_MATERIAL_MME', 
                       'SPEED_RATING_MME', 
                       'SEAT_TYPE_MME', 
                       'STEM_SIZE_MME', 
                       'STEM_TYPE_MME', 
                       'TORQUE_RATING_MME', 
                       'TRAVEL_MME', 
                       'TRIM_MATERIAL_MME']

DEFAULT_STOP_WORDS=['SPECIAL_FEATURES',
                    'CS_SPECIFICATION',
                    '_SPECIFICATION',
                    'EQUIPMENT',
                    'FUNCTION_MM',
                    'SPECIAL_REQUIREMENT',
                    'SPECIAL FEATURES',
                    'RETAINED INFO',
                    'SPECIAL CONDITION',
                    'INDUSTRY REFERENCE',
                    'INTERNAL SPEC REF',
                    'FEATURES',
                    'VENDOR REFERENCE',
                    "INDUSTRY_STANDARD",
                    "INDUSTRY STANDARD",
                    "SHORT_NAME",
                    "SHORT NAME"
                    ]

# CLASS_DESC={'QU_PWR01': 'PowerFlex',
#  'QU_MOUN01': 'Mounting Channel',
#  'QU_GAVA01': 'Gate Valve',
#  'QU_BAVA01': 'Ball Valve',
#  'QU_GLVA01': 'Globe Valve',
#  'QU_CLI01': 'CLIP',
#  'QU_BOLT01': 'BOLT',
#  'QU_PANVJ01': 'PANEL',
#  'QU_CHPL01': 'PLATE',
#  'QU_SRIBE01': 'TUBING',
#  'QU_PRTR01': 'PRESSURE TRANSMITTER',
#  'QU_DPTR01': 'DIFFERENTIAL PRESSURE TRANSMITTER',
#  'QU_LTRAN01': 'LEVEL TRANSMITTER',
#  'QU_PSVA01': 'VALVE',
#  'QU_TESE01': 'TEMPERATURE SENSOR',
#  'QU_LSWT01': 'LEVEL SWITCH',
#  'QU_TETT01': 'TEMPERATURE TRANSMITTER',
#  'QU_FTRAN01': 'FLOW TRANSMITTER',
#  'QU_FMET01': 'FLOW METER',
#  'QU_MOT01': 'MOTOR',
#  'QU_Relay01': 'RELAY',
#  'QU_Relay02': 'RELAY',
#  'QU_TRAN01': 'TRANSFORMER',
#  'PT21UNI': 'UNIONS',
#  'PT21BEN01': 'BEND',
#  'PT21COL01': 'COLLARS',
#  'PT21BEN': 'BENDS',
#  'PT21ADA01': 'ADAPTER',
#  'PT21FLNGWN01': 'FLANGE, WELDNECK',
#  'PT21CONFIT01': 'CONNECTOR, FITTING',
#  'PT21RDCRECC01': 'REDUCER, ECCENTRIC',
#  'PT21RDCRCON01': 'REDUCER, CONCENTRIC',
#  'PT21ELB01': 'ELBOW, PIPE',
#  'PT32ELB01': 'ELBOW, TUBE',
#  'PT20NIS01': 'NIPPLE'}


CHAR_DICT={
    "END_CONNECTION_TYPE":"END CONNECTION",
    "MATERIAL_SPECIFICATION":"SPECIFICATION",
    "XXS":"EXTRA EXTRA STRONG",
    "INSIDE DIAMETER":"INSIDE_DIAMETER",
    "OUTSIDE DIAMETER":"OUTSIDE_DIAMETER",
    "CAGE MATERIAL":"CAGE_MATERIAL",
    "BALL MATERIAL":"BALL_MATERIAL",
    "CLOSURE TYPE":"CLOSURE_TYPE",
    "INTERNAL CLEARANCE":"INTERNAL_CLEARANCE",
    "SPEED RATING":"SPEED_RATING",
    "STATIC LOAD CAPACITY":"STATIC_LOAD_CAP",
    }

FAMILY_SHORT_NAME = {
    "VALVES/ACTUATORS/OPERATORS": "VLV",
    "FASTENERS": "FASTENERS",
    "GASKETS/PACKING/SEALS": "GSP",
    "PIPE/TUBE & FITTINGS": "PTF"
}

cls_class_model = None
cls_selector_model = None
cls_tfidf_model = None

def getModels(FAMILY_SHORT):
    global cls_class_model
    global cls_selector_model
    global cls_tfidf_model

    with open(os.path.join(MODEL_PATH,FAMILY_SHORT,"trained_model.pickle"), 'rb') as cls_model:
        cls_class_model=pickle.load(cls_model)

    with open(os.path.join(MODEL_PATH,FAMILY_SHORT,"selector_model.pickle"), 'rb') as sel_model:
        cls_selector_model=pickle.load(sel_model)

    with open(os.path.join(MODEL_PATH,FAMILY_SHORT,"tfidf_model.pickle"), 'rb') as tf_model:
        cls_tfidf_model=pickle.load(tf_model)

    cls_class_model = cls_class_model
    cls_selector_model = cls_selector_model
    cls_tfidf_model = cls_tfidf_model
    
    
with open(os.path.join(MODEL_PATH,'Language',"trained_model.pickle"), 'rb') as cls_model:
    lang_classification_model=pickle.load(cls_model)

with open(os.path.join(MODEL_PATH,'Language',"selector_model.pickle"), 'rb') as sel_model:
    lang_selector_model=pickle.load(sel_model)

with open(os.path.join(MODEL_PATH,'Language',"tfidf_model.pickle"), 'rb') as tf_model:
    lang_tfidf_model=pickle.load(tf_model)


system_prompt='''Transform data based the pattern given in rule(s). Return output same as input if the rule pattern is not relevant to the input. return output in json format'''

def checkString(text):
    for ch in str(text):
        if ch.isalpha():
            return True
        
        if ch.isdigit():
            return True
    return False


def standardize_mm_data(mm_data,class_desc):
    stand_mmdata={}
    for mk,mv in mm_data.items():
        if mk not in CHARS_WITHOUT_STD:
            match_found=standardization_data.get(f"{mk}::{mv}",None)
            if match_found:
                stand_mmdata[mk]=match_found
            else:
                stand_mmdata[mk]=mv
        else:
            stand_mmdata[mk]=mv
            
    return stand_mmdata



def get_cleaned_char(char):
    feature_name=char.replace('_',' ').strip().lower()
    feature_tks=feature_name.split()
    if feature_tks[-1]=='mm':
        feature_name=' '.join(feature_tks[:-1])

    return feature_name


def get_class(text):
    
    text=text.upper()
    
    text_lang=get_lang(text)
    
    if text_lang!='ENGLISH':
        return pd.Series([text_lang, 'UNDEFINED', 0.0])
    
    if is_valve_component(text) and FAMILY=='VALVES/ACTUATORS/OPERATORS':
        return pd.Series([text_lang,'COMPONENT:VALVE', 0.99])
    

    x_test = cls_tfidf_model.transform([text])
    x_test = cls_selector_model.transform(x_test).astype('float32')
    preds = cls_class_model.predict(x_test) #Returns list 
    prob = cls_class_model.predict_proba(x_test)
    pred_class = preds[0].replace('\xa0', ' ')
    
    return pd.Series([text_lang,pred_class, float(max(prob[0]))])


# Prompts - Function calling
def create_prop_dict(class_name):
    prop_dict={}
    mand_chars=[]
    if class_name in taxonomy_dict:
        features=taxonomy_dict.get(class_name)
        class_desc=class_name
        for feature_tpl in features:
            feature=feature_tpl[0]
            #if 'Mandatory' in feature_tpl[1]:
            #mand_chars.append(feature)
            class_name_modified=' '.join([str(ele).strip() for ele in class_desc.replace(':',' ').replace('_',' ').split(',')]).lower()
            feature_name=feature.replace('_',' ').strip().lower()
            feature_tks=feature_name.split()
            if feature_tks[-1]=='mm' or feature_tks[-1]=='mme':
                feature_name=' '.join(feature_tks[:-1])
            feature_name=feature_name.upper()
            feature_name=feature_name.strip()
            mand_chars.append(feature)
            if feature in allow_values_dict:
                allow_examples=allow_values_dict.get(feature,[])
                examples=', '.join([f"{str(ele).strip()}" for ele in allow_examples[:allow_values_size]])
                if feature in CHAR_ALIASES:
                    feature_with_aliases=",".join([char_als for char_als in CHAR_ALIASES.get(feature,[])])
                    prop_dict[feature]={
                        "type":"string",
                        "description":f"{feature_with_aliases}, e.g. {examples}"    
                    }
                else:
                    prop_dict[feature]={
                        "type":"string",
                        "description":f"{feature_name}, e.g. {examples}"    
                    }
               
            else:
                examples1=all_allowables.get(feature,[])
                if examples1:
                    examples1=', '.join([f"{str(ele).strip()}" for ele in examples1[:allow_values_size]])
                    prop_dict[feature]={
                        "type":"string",
                        "description":f"{feature_name}, e.g. {examples1}"
                    }
                else:
                    prop_dict[feature]={
                        "type":"string",
                        "description":f"{feature_name}"
                    }
    return prop_dict,mand_chars

def get_custom_function(class_name):
    prop_dict,mand_chars=create_prop_dict(class_name)
    custom_functions=None
    if prop_dict:
        class_name_modified=' '.join([str(ele).strip() for ele in class_name.replace('_',' ').replace(':',' ').split(',')]).lower()
        custom_functions = [
            { "type":"function",
             "function":{
                "name": "material_cleansing",
                "description": f"{class_name_modified.upper()} material cleansing.",
                "parameters": {
                    "type": "object",
                    "properties": prop_dict
                },
                "required":mand_chars
                
                }
            }
        ]
    else:
        return None
    return custom_functions


def get_fill_rate_details(fill_df):
    fill_df=fill_df[fill_df.CHAR!='ADDITIONAL_DETAIL']
    fill_groups=fill_df.groupby('CLASS_PRED')
    fill_rate_items=[]
    for g, df in fill_groups:
        item={}
        item['CLASS']=g
        item['ITEM_COUNT']=df['Item_No'].nunique()
        item['CHAT_COUNT']=df[df['Item_No'].isin([df['Item_No'].tolist()[0]])].shape[0]
        item['CHAR_TOTAL']=df.shape[0]
        item['FILL_TOTAL']=df[(df['CHAR VALUES']!='')&(~df['CHAR VALUES'].isnull())].shape[0]
        item['FILL_RATE']=round((item['FILL_TOTAL']/item['CHAR_TOTAL'])*100,2)
        fill_rate_items.append(item)
    return pd.DataFrame(fill_rate_items)

def get_fill_rate_chart(fill_rate):
    labels = fill_rate['CLASS'].tolist()
    sizes = fill_rate['FILL_RATE'].tolist()
    source = pd.DataFrame({"category": labels, "value": sizes})

    piechart=alt.Chart(source).mark_arc().encode(
        theta="value",
        color="category"
    ).properties(height=450,width=450)
    #pie = piechart.mark_arc(outerRadius=90)
    #pie_text = piechart.mark_text(radius=110, size=20).encode(text="value:N")

    return piechart

def Sorting(lst):
    if lst:
        lst2 = sorted(lst, key=len, reverse=True)
        return lst2
    return lst

def get_additional_text(text,char_values):
    additional_text=text
    sorted_char_vals=Sorting(char_values)
    for sc in sorted_char_vals:
        sc=re.sub(r'^\W*', '', sc)
        additional_text=re.sub(rf'(?i)\b{re.escape(sc)}\b', ' ', additional_text)
        additional_text=re.sub(rf'(?i)\s+{re.escape(sc)}\s+', ' ', additional_text)
        additional_text=additional_text.replace(f' {sc} ',' ')
        
    additional_text=' '.join([ele for ele in additional_text.split(' ') if (str(ele).strip()!='' and len(str(ele).strip())>1)])
    additional_text=re.sub(' +', ' ', additional_text)
    additional_text=re.sub(':+', ':', additional_text)
    additional_text.strip()
    return additional_text


def get_clean_text(text):
    blob = TextBlob(clean(text,lower=False))
    return ' '.join(list(blob.noun_phrases))

def get_confidence_score(score):
    sim_score=1-score
    confidence_score=round(((math.pi-math.acos(sim_score))/math.pi)*100,2)
    return confidence_score


def clean_text(text):
    delimiters = [";"]
    text=', '.join([ele.strip() for ele in text.split(',')])
    for dl in delimiters:
        text=', '.join([ele.strip() for ele in text.split(dl)])
        
    text=re.sub(r'^\W*', '', text)
    text=re.sub(' +', ' ', text)
    text=text.strip()
    
    return text

def get_llm_response(text,custom_functions, class_name):
    messages=[{"role":"system", "content":cleanse_system_prompt},
              {"role":"user", "content":text}]
    response=client.chat.completions.create(
        model=config_details.get("CHATGPT_MODEL"),
        seed=42,
        temperature=0.0,
        messages=messages,
        tools=custom_functions,
        tool_choice={"type": "function", "function": {"name": "material_cleansing"}}
    )

    raw_results1=response.choices[0].message.tool_calls[0].function.arguments

    # raw_results = ast.literal_eval(raw_results)
    raw_results1= json.loads(raw_results1)
    
    
    raw_results={}
    for key,val in raw_results1.items():
        #raw_results[f"{key.replace(' ','_')}_MME"]=val
        raw_results[key]=val
        

    # st.write(raw_results)

    # raw_results = json.dumps(raw_results)
    # results_json= json.loads(raw_results)
    # return results_json
    return raw_results


def format_results(item_no,text,m_class,results_json):
    char_values=DEFAULT_STOP_WORDS
    for cls_tks in m_class.split(":"):
        char_values.append(cls_tks)
    char_seq_numbers=[]
    results_list=[]
    stand_mm_data={}
    try:
        stand_mm_data=standardize_mm_data(results_json,m_class)
    except:
        pass
    #st.write(stand_mm_data)
    for char in [char_tpl[0] for char_tpl in taxonomy_dict.get(m_class,[])]:
        res_dict={}
        res_dict['Item_No']=item_no
        res_dict['CLASS']=m_class
            
        if char in results_json:
            if results_json.get(char,'') not in ['','N/A','UNKNOWN','None']:
                
                char_tokens=char.split("_")
                if char_tokens[-1]=='MME':
                    char_values.append("_".join(char_tokens[:-1]))
                    char_values.append(" ".join(char_tokens[:-1]))
                
                res_dict['Sequence_No']=char_seq_dict.get((m_class,char),None)
                res_dict['CHAR']=char
                res_dict['CHAR VALUES']=results_json.get(char,'')
                
                if char in stand_mm_data:
                    res_dict['STAND CHAR VALUES']=stand_mm_data.get(char,'')
                else:
                    res_dict['STAND CHAR VALUES']=results_json.get(char,'')
                
                if res_dict['Sequence_No']:
                    char_seq_numbers.append(int(res_dict['Sequence_No']))
                #res_dict['CHAR VALUES']=results_json.get(char,{}).get("ENTITY",'')
                #res_dict['CONFIDENCE_LEVEL']=results_json.get(char,{}).get("SCORE",0.0)
                char_values.append(res_dict['CHAR VALUES'])
                if res_dict['CHAR VALUES'] in CHAR_DICT:
                    char_values.append(CHAR_DICT.get(res_dict['CHAR VALUES']))
                char_values.append(char)
                char_values.append(char.replace(' ','_'))
                if char in CHAR_DICT:
                    char_values.append(CHAR_DICT.get(char))
                char_values.append(get_cleaned_char(char))
            else:
                res_dict['Sequence_No']=char_seq_dict.get((m_class,char),None)
                res_dict['CHAR']=char
                res_dict['CHAR VALUES']=''
                res_dict['STAND CHAR VALUES']=''
                if res_dict['Sequence_No']:
                    char_seq_numbers.append(int(res_dict['Sequence_No']))
        else:
            res_dict['Sequence_No']=char_seq_dict.get((m_class,char),None)
            res_dict['CHAR']=char
            res_dict['CHAR VALUES']=''
            res_dict['STAND CHAR VALUES']=''
            if res_dict['Sequence_No']:
                char_seq_numbers.append(int(res_dict['Sequence_No']))
               
        results_list.append(res_dict)
        
    char_values=[ele for ele in char_values if ele]
    additional_text = get_additional_text(text,char_values)
    #st.write(res_dict)
    if additional_text:
        res_dict={}
        res_dict['Item_No']=item_no
        res_dict['CLASS']=m_class
        res_dict['Sequence_No']=max(char_seq_numbers)+1
        res_dict['CHAR']='ADDITIONAL_DETAIL'
        res_dict['CHAR VALUES']=additional_text.strip()
        res_dict['STAND CHAR VALUES']=additional_text.strip()
        results_list.append(res_dict)
    formated_result_df=pd.DataFrame(results_list)
    return formated_result_df

#def get_bg_color(val):
#    return ['background-color: lime']*len(val) if val.CLASS_PRED==gt_data_dict.get(val.Item_No) else ['background-color: pink']*len(val)

def fill_rate_color(val):
    if val>=75:
        color = 'lime' 
    elif val>=50:
        color='yellow'
    else:
        color='pink'
    return f'background-color: {color}'

def review_fill_color(val):
    if val=='PASSED':
        color = 'lime'
    elif val=='NOT FOUND':
        color = 'yellow'
    else:
        color='pink'
    return f'background-color: {color}'


def format_classification_report(cr):
    for k,v in cr.items():
        if k=='accuracy':
            cr[k]=round(cr[k]*100,2)
        else:
            for ak,av in v.items():
                if ak=='support':
                    cr[k][ak]=int(cr[k][ak])
                else:
                    cr[k][ak]=round(cr[k][ak]*100,2)
    
    cf_df=pd.DataFrame(cr)
    cf_df_tran=cf_df.transpose()
    cf_df_tran=cf_df_tran.round(decimals=2)
    cf_df_tran['support']=cf_df_tran['support'].astype(int)
    cf_df_tran=cf_df_tran.rename(columns={'precision':'Pression (%)', 'recall':'Recall (%)', 'f1-score':'F1 (%)','support':'MM Count'})
    return cf_df_tran
    

#########################################################################################################################################################################################################################################################
#########################################################################################################################################################################################################################################################


from fastapi import FastAPI, HTTPException, UploadFile, File
from pydantic import BaseModel
import pandas as pd
import os

# app = FastAPI()

class SingleMaterialRequest(BaseModel):
    long_text: str = None
    short_text: str = None
    family: str = None
    mmId: str = None

class MaterialTextRequest(BaseModel):
    mmID: str = None

class BulkMaterialRequest(BaseModel):
    family: str
    runtime: str
    dateTime: datetime = None

    # className: List[str]
    # mmId: List[str]

class ResultRequest(BaseModel):
    family: str
    classId: List[str] = []
    mmId: List[str] = []

class DashboardData(BaseModel):
    family: List[str]
    classId: List[str] = []
    characteristics: List[str] = []
    materialID: List[str] = []
    # source: List[str] = []
    importance: List[str] = []

# For status option
class StatusEnum(Enum): 
    accepted = "Accepted"
    rejected = "Rejected"
    pending = "Pending"

# For request body
class UserCreateRequest(BaseModel):  
    firstName: str
    lastName: str
    email: str
    password: str
    confirmPassword: str
    role: List[str] = []

class UserStatusUpdateRequest(BaseModel):
    status: StatusEnum

class getScheduleData(BaseModel):
    familyID: List[str] = []
    statusId: List[str] = []

class SchEditedData(BaseModel):
    id: str
    family: str
    runtime: str
    dateTime: datetime

def get_mmData(mmID):
    material_data = pd.read_csv("D:/mm_project/Archive 1/Latest Project Path/Project/VALVES_MMS.csv")
    mmData = material_data[material_data['ID'] == mmID]

    longText = mmData['long_text'].unique()[0]
    shortText = mmData['short_text'].unique()[0]
    familyName = familyname
    mmData_dict = dict(zip(mmData['CHARACTERISTIC'], mmData['CURRENT VALUE']))

    return longText, shortText, familyName, mmData_dict

@app.get("/get_text")
async def get_text_data(MMId: str, db: Session = Depends(get_db)):
    # mmID = request.mmID
    print("mmID", MMId)

    longText, shortText, familyName, _ = get_mmData(MMId)

    # mmData = material_data[material_data['ID'] == mmID]

    # longText = mmData['long_text'].unique()[0]
    # shortText = mmData['short_text'].unique()[0]
    # familyName = family_name

    response = {
        "long_text": longText,
        "short_text": shortText,
        "family": familyName,
        "mmId": MMId
    }

    return JSONResponse(status_code=200, content={"result": response, "message": "Success"})


@app.post("/Single-material/")
async def classify_and_cleanse_single_material(request: SingleMaterialRequest, db: Session = Depends(get_db)):
    print("AAAAAAAAA")
    formatted_results=pd.DataFrame()
    fillrate_df=pd.DataFrame()
    cleanse_data_status=False
    classification_result = {}
    proposedLongText = {}
    proposedShortText = {}
    text_items = []

    # family_name = request.family
    mmID = request.mmId
    # mmID = 'F3 - 000000000060053009'
    print("mmID", mmID)
    longText, shortText, family_name, mmData_dict = get_mmData(mmID)
    # mmData = material_data[material_data['ID'] == mmID]
    # mmData_dict = dict(zip(mmData['CHARACTERISTIC'], mmData['CURRENT VALUE']))
    print(mmData_dict)

    print(family_name, request.long_text)

    # taxonomy = read_taxonomy("VALVES/ACTUATORS/OPERATORS", SessionLocal())
    # taxonomy_dict, char_seq_dict, allow_values_dict = read_taxonomy(family_name, SessionLocal())
    # read_taxonomy(family_name, SessionLocal())
    

    # if request.long_text:
    #     text_items.append(request.long_text)

    # if request.short_text:
    #     text_items.append(request.short_text)

    if longText:
        text_items.append(longText)

    if shortText:
        text_items.append(shortText)

    if not text_items:
        raise HTTPException(status_code=400, detail="At least one of long_text or short_text must be provided")
    

    material_text = '. '.join(text_items)

    familyShortName = FAMILY_SHORT_NAME.get(family_name, '')
    print("familyShortName", familyShortName)
    getModels(familyShortName)

    # Classification step
    mm_lang, material_class, confidence_score = get_class(material_text)
    print('confidence_score', confidence_score)
    # if confidence_score < 0.45:
    #     return {"message": "Class prediction confidence is too low", "class_predicted": "UNDEFINED", "language_detected": mm_lang}
    if mm_lang != "ENGLISH":
        return {'status': "Failed", "message": "Language detected is other than English", "class_predicted": "UNDEFINED", "language_detected": mm_lang}

    confidence_score_formated = f"{confidence_score * 100: .2f}%"

    read_taxonomy(family_name, db)
    read_allowableValues(family_name, material_class, db)

    # Cleansing step
    custom_functions = get_custom_function(material_class)

    long_llm_resp = None
    # if request.long_text and mm_lang == 'ENGLISH':
    #     clean_long_text = clean_text(request.long_text)
    if longText and mm_lang == 'ENGLISH':
        clean_long_text = clean_text(longText)
        clean_long_text=clean_long_text.replace('*', ' ')
        try:
            long_llm_resp = get_llm_response(clean_long_text, custom_functions, material_class)
        except Exception as e:
            long_llm_resp = {}
    else:
        long_llm_resp = {}

    # short_llm_resp = None
    # if request.short_text:
    #     clean_short_text = clean_text(request.short_text)
    #     short_llm_resp = get_llm_response(clean_short_text, custom_functions, material_class)

    # Combine responses from long and short text
    # if short_llm_resp:
    #     for sk, sv in short_llm_resp.items():
    #         if sk not in long_llm_resp:
    #             long_llm_resp[sk] = sv

    # Formatting the results

    try:
        formatted_results=format_results(mmID,clean_long_text,material_class,long_llm_resp)
        formatted_results['Current Long Text']=clean_long_text
        formatted_results=formatted_results.rename(columns={'CLASS':'CLASS_PRED'})
        formatted_results=formatted_results[['Item_No', 'Current Long Text', 'CLASS_PRED', 'Sequence_No',  'CHAR', 'CHAR VALUES','STAND CHAR VALUES']]
        formatted_results[['CHAR VALUES','STAND CHAR VALUES']]=formatted_results.apply(lambda x: get_missing_data(x),axis=1)

        formatted_results1=post_process(formatted_results)
        fillrate_df=get_fill_rate_details(formatted_results1)
        cleanse_data_status=True
    except:
        raise HTTPException(status_code=400, detail="Invalid Class or Text")
    
    if cleanse_data_status and formatted_results.shape[0]:
        cleaned_std_data_dict={row['CHAR']:row['STAND CHAR VALUES'] for ind,row in formatted_results1.iterrows() if row['CHAR']!='ADDITIONAL_DETAIL'}
        st_generated=st_text_generate(cleaned_std_data_dict, material_class)
        lt_generated = ltTextGenerated(cleaned_std_data_dict, material_class)
        print(lt_generated)

    cleansed_results = formatted_results1[['Sequence_No',	'CHAR',	'CHAR VALUES',	'STAND CHAR VALUES',	'REVIEW']].copy()
    cleansed_results = cleansed_results.rename(columns={'STAND CHAR VALUES': 'PROPOSED VALUES'})
    cleansed_results['CURRENT VALUE'] = cleansed_results['CHAR'].map(mmData_dict).fillna('')
    # short_long_text = formatted_results1[['Item_No',	'Current Long Text',	'CLASS_PRED']].drop_duplicates().copy()
    # short_long_text['CLASS_PRED'] = f"{material_class}({confidence_score_formated})"
    # short_long_text['ST GENERATED'] = st_generated

    classification_result['Item_No'] = mmID
    classification_result['material_class'] = material_class
    classification_result['confidence_score'] = confidence_score_formated
    classification_result['language_detected'] = mm_lang

    proposedLongText['Item_No'] = mmID
    proposedLongText['current_long_text'] = longText
    proposedLongText['proposed_long_text'] = lt_generated

    proposedShortText['Item_No'] = mmID
    proposedShortText['current_short_text'] = shortText
    proposedShortText['proposed_short_text'] = st_generated

    response ={
        "classification_result": [classification_result],
        "proposed_long_text": [proposedLongText],
        "proposed_short_text": [proposedShortText],
        "cleansing_results": cleansed_results.to_dict(orient="records"),
        # "short_long_text": short_long_text.to_dict(orient="records"),
        "fill_rate": fillrate_df.to_dict(orient="records")
    }

    # print(response)

    # return JSONResponse(status_code=200, content={"result": response, "message": "Success"})
    return response

# @app.post("/bulk_material/")
# async def bulk_material(request: BulkMaterialRequest, db: Session = Depends(get_db)):
def cleanseData(family, sch_id, db):

    print("family", family)
    print("sch_id", sch_id)

    familyShortName = FAMILY_SHORT_NAME.get(family, '')
    print("familyShortName", familyShortName)
    getModels(familyShortName)

    try:
        while True:
            rowsUpdated = db.query(ScheduledCleansingHistory).filter(ScheduledCleansingHistory.SCH_Id == sch_id, ScheduledCleansingHistory.Scheduled_Status == MaterialTextStatus.SCHEDULED).update({ScheduledCleansingHistory.Scheduled_Status: MaterialTextStatus.INPROGRESS})
            print("rowsUpdated", rowsUpdated)
            if rowsUpdated > 0:
                db.commit()
                break
        read_taxonomy(family, db)
        # read_allowableValues(family_name, material_class, db)

        # print("taxonomy_dict", taxonomy_dict)
        print("got Taxonomy")

        query = '''SELECT TOP 11 MM_Id, Long_Text, Short_Text FROM MaterialText 
            WHERE Status = 'Yet to Cleansed' AND Family_Name = ? '''
        
        if family:
            # materialData = db.query(MaterialText).filter(
            #     MaterialText.Status == 'Not Cleansed',
            #     MaterialText.Family_Name == family,
            #     # MaterialText.MM_Id == mmId
            # ).limit(25)
            
            materialData = pd.read_sql(query, db.bind, params=(family,))
            
            if not materialData.empty:
                mm_ids = materialData['MM_Id'].tolist()
                print("mmids", mm_ids)
                db.query(MaterialText).filter(MaterialText.MM_Id.in_(mm_ids)).update({MaterialText.SCH_Id: sch_id})
                db.commit()
            else:
                raise HTTPException(status = 'Error', detail=f"No material to cleanse in {family} family")

        else:
            raise HTTPException(status = 'Error', detail="'Family' must be provided.")
        
        # print("materialData", materialData)
        materialCount = len(mm_ids)
        print("materialCount", materialCount)
        # materialData = materialData.all()
        # materialData = pd.DataFrame(materialData)
        # print("materialData_DF", materialData)

        # materialData = pd.read_excel("D:\\mm_project\\Archive 1\\Latest Project Path\\Project\\Input\\LT_3_2nd_3_1000 - Copy (2).xlsx", sheet_name = 'INPUT_DATA')
            

        # file_location = f"{INPUT_FOLDER}/{file.filename}"
        # with open(file_location, "wb+") as file_object:
        #     file_object.write(file.file.read())

        # #Read uploaded file based on type
        # file_name = file.filename
        # file_type = file_name.split(".")[-1]

        # if file_type == "csv":
        #     test_data = pd.read_csv(os.path.join(INPUT_FOLDER, file_name))
        # else:
        #     test_data = pd.read_excel(os.path.join(INPUT_FOLDER, file_name), "INPUT_DATA")

        # test_data=test_data[['Item_No','long_text','short_text']]
        mmidsWithoutLongText = materialData[materialData['Long_Text'] == 'NOT AVAILABLE']['MM_Id'].tolist()
        charDataTextdf = None
        if mmidsWithoutLongText:
            mmidplaceholder = ','.join(['?']*len(mmidsWithoutLongText))
            charDataQuery = f'''SELECT MM_Id, Characteristic_Name, Current_Value FROM CharacterData WHERE Family_Name = ? AND MM_Id IN ({mmidplaceholder})'''
            param = (family,) + tuple(mmidsWithoutLongText)
            charDatadf = pd.read_sql(charDataQuery, db.bind, params=param)
            if not charDatadf.empty:
                charDataGroup = charDatadf.groupby('MM_Id')
                charDataList = []
            
                # Creating the text using the Character data 
                for g, df in charDataGroup:
                    charLevelData = {}
                    charLevelData['MM_Id'] = g
                    charDataDict = {row['Characteristic_Name']: row['Current_Value'] for ind, row in df.iterrows()}
                    char_data = ltTextGenerated(charDataDict)
                    charLevelData['char_data'] = char_data
                    charDataList.append(charLevelData)
            
                charDataTextdf = pd.DataFrame(charDataList)

        if charDataTextdf is not None:
            materialData = pd.merge(materialData, charDataTextdf, on='MM_Id', how='left')


        # materialData=materialData[['MM_Id','Long_Text','Short_Text']]

        #Process data
        # materialData['LONG TEXT']=materialData.apply(lambda x: str(x['Long_Text'])+'. '+str(x['Short_Text']) if x['Short_Text'] else str(x['Long_Text']), axis=1)
        materialData['LONG TEXT']=materialData.apply(lambda x: f'{str(x["Long_Text"])} ; {str(x["Short_Text"])}' if str(x['Long_Text'])!='NOT AVAILABLE' else f'{str(x["Short_Text"])} ; {str(x["char_data"]) if pd.notna(x.get("char_data")) else ""}',axis=1)
        
        class_data = db.query(Class.Class_Name, Class.Class_Id).all()
        class_dict = {className: class_id for className, class_id in class_data}

        batchSize = 3
        batches = [materialData[i: i+batchSize] for i in range(0, materialData.shape[0], batchSize)]
        i=1
        cleansedCount = 0
        for test_data in batches:
            print('i',i)
            ids = test_data['MM_Id'].tolist()
            batchCount = len(ids)
            print("batchCount", batchCount)
            db.query(MaterialText).filter(MaterialText.MM_Id.in_(ids)).update({MaterialText.Status: "In Progress"})
            db.commit()
            i+=1
            test_data[['Lang','CLASS_PRED','Probabilty']]=test_data['LONG TEXT'].apply(get_class)
            # test_data.to_csv(os.path.join(RESULTS_PATH,"classification_results.csv"),index=False)
            test_data=test_data.drop(columns=['LONG TEXT'])

            class_results=test_data.rename(columns={"long_text":"Current Long Text","Confidence_Score":"PRED_CLASS_CONFIDENCE"})
            class_results['Class_Predicted_Id'] = class_results['CLASS_PRED'].map(class_dict)
            # class_results['Class_Predicted_Id'] = class_results['Class_Predicted_Id'].fillna(value=None)
            current_datetime = datetime.now()
            class_results['Created_On'] = current_datetime.strftime('%Y-%m-%d %H:%M:%S')
            class_results = class_results.fillna("")
            class_results.loc[class_results['Lang'] == 'NON-ENGLISH', 'CLASS_PRED'] = ""
            classification_result = class_results.to_dict(orient='records')
            classification_result = [
                {**record, 'Class_Predicted_Id': None if record['Class_Predicted_Id'] == "" else record['Class_Predicted_Id']}
                for record in classification_result
            ]

            db.bulk_insert_mappings(ClassResult, classification_result)
            db.commit()

            # print("test_data", test_data)

            sample_input = test_data[(test_data["Probabilty"] > 0.50) &
                                    (test_data["Lang"] == "ENGLISH")]
            # print("sample_input", sample_input)
            rowcount=sample_input.shape[0]
            
            formatted_results_all=[]
            count=0.0
            for ind,row in sample_input.iterrows():
                count=count+1
                try:
                    custom_functions=get_custom_function(row['CLASS_PRED'])
                    # print('custom_functions', custom_functions)
                    long_text_cleaned=None
                    long_text_llm_resp={}

                    if row['Long_Text']!='NOT AVAILABLE':
                        long_text_cleaned=clean_text(str(row['Long_Text']))
                        long_text_cleaned=long_text_cleaned.replace('*',' ')
                        long_text_llm_resp=get_llm_response(long_text_cleaned,custom_functions, row['CLASS_PRED'])
                    elif row['char_data']:
                        long_text_cleaned=clean_text(str(row['char_data']))
                        long_text_cleaned=long_text_cleaned.replace('*',' ')
                        long_text_llm_resp=get_llm_response(long_text_cleaned,custom_functions, row['CLASS_PRED'])

                    # if row['Long_Text']:
                    #     long_text_cleaned=clean_text(str(row['Long_Text']))
                    #     long_text_cleaned=long_text_cleaned.replace('*',' ')
                    #     long_text_llm_resp=get_llm_response(long_text_cleaned,custom_functions, row['CLASS_PRED'])
                    
                    formatted_results=format_results(row['MM_Id'],long_text_cleaned,row['CLASS_PRED'],long_text_llm_resp)
                    formatted_results_all.append(formatted_results)
                except Exception as err:
                    print(err)
                    print(f"Not Cleansed:{row['MM_Id']}")
                    formatted_results=format_results(row['MM_Id'],long_text_cleaned,row['CLASS_PRED'],{})
                    formatted_results_all.append(formatted_results)
            mmids = []
            if formatted_results_all:
                formatted_results_df=pd.concat(formatted_results_all)
                # print("formatted_results_df", formatted_results_df.columns)
                # bulk_cleanse_results_path = os.path.join(RESULTS_PATH, "bulk_cleanse_results.csv")
                # formatted_results_df.to_csv(bulk_cleanse_results_path, index=False)

                # print("test_data", test_data)

                # class_results=test_data.rename(columns={"long_text":"Current Long Text","Confidence_Score":"PRED_CLASS_CONFIDENCE"})
                # print("class_results", class_results)
                merged_results=pd.merge(formatted_results_df,class_results,left_on=['Item_No'],right_on=['MM_Id'],how='left')
                # print("merged_results", merged_results.columns)
                merged_results=merged_results[['MM_Id', 'Long_Text', 'CLASS_PRED','Probabilty', 'Sequence_No',  'CHAR', 'CHAR VALUES','STAND CHAR VALUES', 'Class_Predicted_Id']]
                merged_results[['CHAR VALUES','STAND CHAR VALUES']]=merged_results.apply(lambda x: get_missing_data(x),axis=1)

                print('merged_results', merged_results)
                post_process_df=post_process(merged_results)
                post_process_df=post_process_df.fillna("")
                # print("post_process_df", post_process_df.columns)
                
                post_process_df = post_process_df.rename(columns = {
                    'CHAR': 'Characteristic_name', 'CHAR VALUES': 'Suggested_Value', 'STAND CHAR VALUES': 'Proposed_Value', 
                    'REVIEW': 'Auto_Review', 'Class_Predicted_Id': 'Class_Id'})
                # print(taxonomyClassCharImp_dict)
                # print(post_process_df[['Class_Id', 'Characteristic_name']])
                post_process_df['Importance'] = post_process_df[['Class_Id', 'Characteristic_name']].apply(lambda row: taxonomyClassCharImp_dict.get((row['Class_Id'], row['Characteristic_name']), np.nan), axis=1)
                post_process_df['Importance'] = post_process_df['Importance'].astype('Int64')
                post_process_df['Created_On'] = current_datetime.strftime('%Y-%m-%d %H:%M:%S')
                post_process_df['Family_Name'] = family
                # print(post_process_df['Importance'])
                mmidlist = post_process_df['MM_Id'].unique().tolist()
                cleansedData_dict = post_process_df.to_dict(orient='records')
                # print("cleansedData_dict", cleansedData_dict)
                # mmids = list(set(item['MM_Id'] for item in cleansedData_dict))
                mmids.extend(set(item['MM_Id'] for item in cleansedData_dict))

                db.bulk_insert_mappings(CleansedData, cleansedData_dict)
                db.commit()

                # Update the Material Status (if Cleansed or not)
                db.query(MaterialText).filter(MaterialText.MM_Id.in_(mmids)).update({MaterialText.Status: "Cleansed"})
                db.commit()

                # bulk_fill_rate_df=get_fill_rate_details(post_process_df)
                # bulk_fill_rate_df = bulk_fill_rate_df.fillna("")
                post_process_df_groups=post_process_df.groupby('MM_Id')

                st_df_rows=[]
                for g,df in post_process_df_groups:
                    new_row={}
                    new_row['Family_Name'] = family
                    new_row['MM_Id']=g
                    new_row['Long_Text']=df['Long_Text'].unique().tolist()[0]
                    new_row['CLASS_PRED']=df['CLASS_PRED'].tolist()[0]
                    cleaned_std_data_dict={row['Characteristic_name']:row['Proposed_Value'] for ind,row in df.iterrows() if row['Characteristic_name']!='ADDITIONAL_DETAIL'}
                    st_generated=st_text_generate(cleaned_std_data_dict, new_row.get('CLASS_PRED'))
                    lt_generated = ltTextGenerated(cleaned_std_data_dict, new_row.get('CLASS_PRED'))
                    new_row['Propsed_Short_Text']=st_generated
                    new_row['Proposed_Long_Text']=lt_generated
                    new_row['Created_On'] = current_datetime.strftime('%Y-%m-%d %H:%M:%S')
                    st_df_rows.append(new_row)
                
                # print("st_df_rows", st_df_rows)

                # Insert data in ShoetLongText Table
                db.bulk_insert_mappings(ShortLongText, st_df_rows)
                db.commit()
            
            
            
            mmid_notCleansed = list(set(ids).difference(mmids))
            
            if mmid_notCleansed:
                mmNotCleansed = class_results[class_results['MM_Id'].isin(mmid_notCleansed)]
                foreignLang_ids = mmNotCleansed[mmNotCleansed['Lang'] != 'ENGLISH']['MM_Id'].tolist()
                lowConfidence_ids = mmNotCleansed[(mmNotCleansed['Probabilty'] <= 0.50) & (mmNotCleansed['Lang'] == 'ENGLISH')]['MM_Id'].tolist()
                case_exp = case(
                    
                    (MaterialText.MM_Id.in_(foreignLang_ids), "Not Cleansed(Foreign Language)"),
                    (MaterialText.MM_Id.in_(lowConfidence_ids), "Not Cleansed(Low Confidence)"),
                    else_="Not Cleansed"
                )
                # db.query(MaterialText).filter(MaterialText.MM_Id.in_(mmid_notCleansed), MaterialText.Status == "In Progress").update({MaterialText.Status: "Not Cleansable"})
                db.query(MaterialText).filter(MaterialText.MM_Id.in_(mmid_notCleansed), MaterialText.Status == "In Progress").update({MaterialText.Status: case_exp})

                db.commit()
            
            cleansedCount += batchCount
            print("cleansedCount", cleansedCount)
            ProgressPercentage = (cleansedCount / materialCount) * 100
            print("ProgressPercentage", ProgressPercentage)

            db.query(ScheduledCleansingHistory).filter(ScheduledCleansingHistory.SCH_Id == sch_id, ScheduledCleansingHistory.Scheduled_Status == MaterialTextStatus.INPROGRESS).update({ScheduledCleansingHistory.Scheduled_Progress: ProgressPercentage})
            db.commit()
            print("updated Progress")

        db.query(ScheduledCleansingHistory).filter(ScheduledCleansingHistory.SCH_Id == sch_id, ScheduledCleansingHistory.Scheduled_Status == MaterialTextStatus.INPROGRESS).update({ScheduledCleansingHistory.Scheduled_Status: MaterialTextStatus.CLEANSED})
        db.commit()

        return JSONResponse(status_code=200, content={"status": "Success", "message": "The Scheduled Family has been Cleansed"})

    except Exception as e:
        print(e)
        db.rollback()
        raise HTTPException(status_code=400, detail="Something went wrong")

        # class_data = db.query(Class.Class_Name, Class.Class_Id).all()

        
        # classification_result = class_results.to_dict(orient='records')

#             session.bulk_insert_mappings(Taxonomy, data_dict)
# session.commit()

#             data = json.loads(data_json)

# # Create a list of dictionaries for bulk insertion
# rows = []
# num_items = len(data["Item_No"])

# for i in range(num_items):
#     row = {
#         "item_no": data["Item_No"][str(i)],
#         "current_long_text": data["Current Long Text"][str(i)],
#         "short_text": data["short_text"][str(i)],
#         "lang": data["LANG"][str(i)],
#         "class_pred": data["CLASS_PRED"][str(i)],
#         "pred_class_confidence": data["PRED_CLASS_CONFIDENCE"][str(i)],
#     }
#     rows.append(row)




            # return {
            #     "message":"File processed successfully",
            #     "classification_results":class_results.to_dict(),
            #     "fill_rate":bulk_fill_rate_df.to_dict(),
            #     "cleansed_result": post_process_df.to_dict()
            # }
    # except:
    #     raise HTTPException(status_code=400)
@app.post("/family-cleanse/")
def bulk_material(request: BulkMaterialRequest, db: Session = Depends(get_db)):
    try:
        family = request.family
        runtime = request.runtime
        scheduleTime = request.dateTime
        current_datetime = datetime.now()

        print("scheduleTime", scheduleTime)

        # Define the format of the datetime string
        # format_string = "%Y-%m-%d %H:%M:%S.%f"

        # Convert the string to a datetime object
        # datetime_obj = datetime.strptime(scheduleTime, format_string)

        # datetime_obj = pytz.utc.localize(scheduleTime)

        local_time = scheduleTime.astimezone(pytz.timezone('Asia/Kolkata'))

        ScheduleTimeLocal = local_time.replace(tzinfo=None)

        print(ScheduleTimeLocal)

        print("AAAAA")
        
        scheduleData = ScheduledCleansingHistory(
                            Family_Name = family, 
                            Scheduled_Status = MaterialTextStatus.SCHEDULED,
                            Scheduled_Time =  ScheduleTimeLocal,
                            Scheduled_Progress = 0.00,
                            Created_On = current_datetime.strftime('%Y-%m-%d %H:%M:%S')
                            )
        
        db.add(scheduleData)
        db.commit()

        generated_sch_id = str(scheduleData.SCH_Id)
        print("runtime", runtime)
        print("generated_sch_id", generated_sch_id)
        if runtime == "now":
            print("NOW")
            # cleanseData(family, generated_sch_id, db)
            threading.Thread(target=cleanseData, args = (family, generated_sch_id, db), daemon=True).start()
            return JSONResponse(status_code=200, content={ "status": "Success", "message": f"Cleansing for the family {family} has been started"})

        else:
            return JSONResponse(status_code=200, content={ "status": "Success", "message": f"The family {family} has been scheduled for Cleansing"})
    except Exception as e:
        print(e)
        db.rollback()
        raise HTTPException(status = 'Error', detail="Something went wrong.")
    
@app.get("/family_name")
def get_familyTree(DB: Tuple[Session , Cursor]= Depends(getdb)):
    db, cursor = DB
    query = "select DISTINCT tx.Family_Name, tx.Class_Id, cl.Class_Name, cr.MM_Id from Taxonomy as tx  join Class as cl on tx.Class_Id = cl.Class_Id left outer join ClassResult as cr on cr.Class_Predicted_Id = cl.Class_Id"
    cursor.execute(query)
    results = cursor.fetchall()
    
    data={"families":[]}
    famDict = {}
    for family_name, class_id, class_name, mm_id in results:

        if family_name not in famDict:
            famDict[family_name] = {
                "value": family_name,
                "label": family_name,
                "classes": {}
            }
            data["families"].append(famDict[family_name])

        if class_id not in famDict[family_name]["classes"]:
            famDict[family_name]["classes"][class_id] = {
                "value": class_id,
                "label": class_name,
                "mmId": []
            }
        if mm_id:
            famDict[family_name]["classes"][class_id]["mmId"].append({
                "value": mm_id,
                "label": mm_id
            })
    for family in data['families']:
        family['classes'] = list(family['classes'].values())

    return {
        "status":"Success", 
        "message":"Data retrieved successfully.", 
        "data": data
    }
    
@app.get("/family_name1")
def get_familyTree(db: Session = Depends(get_db)):

    # familyName_data = db.query(Taxonomy.Family_Name).distinct().all()
    # data={"families":[]}
    # for family in familyName_data:
    #     famDict ={
    #         "value":family[0],
    #         "label":family[0],
    #         "classes":[]
    #     }

    #     classData = db.query(Class.Class_Id, Class.Class_Name).filter(Class.Family_Name == family[0]).distinct().all()
    #     for clsdata in classData:
    #         classDict={
    #             "value": clsdata[0],
    #             "label": clsdata[1],
    #             "mmId": []
    #         }

    #         mmIdData = db.query(CleansedData.MM_Id).filter(CleansedData.Class_Id ==clsdata[0]).distinct().all()
    #         for mmData in mmIdData:
    #             mmDict={
    #                 "value": mmData[0],
    #                 "label": mmData[0]
    #             }

    #             classDict['mmId'].append(mmDict)
    #         famDict['classes'].append(classDict)
    #     data['families'].append(famDict)
    # results = db.query(
    #         Taxonomy.Family_Name,
    #         Taxonomy.Class_Id,
    #         Class.Class_Name,
    #         ClassResult.MM_Id
    #     ).join(Class, Taxonomy.Class_Id == Class.Class_Id).outerjoin(ClassResult, ClassResult.Class_Predicted_Id == Class.Class_Id).distinct().all()
    
    # query = "SELECT DISTINCT tx.Family_Name, tx.Class_Id, cl.Class_Name, cr.MM_Id from Taxonomy as tx left join Class as cl on tx.Class_Id = cl.Class_Id left outer join ClassResult as cr on cr.Class_Predicted_Id = cl.Class_Id"
    # results = db.query(Class).all()
    query = "SELECT DISTINCT tx.Family_Name, tx.Class_Id, cl.Class_Name, cr.MM_Id from Taxonomy as tx  join Class as clon tx.Class_Id = cl.Class_Id left outer join ClassResult as cr on cr.Class_Predicted_Id = cl.Class_Id;"

    results = pd.read_sql(query, db.bind)
    # return results

    data={"families":[]}
    famDict = {}
    for family_name, class_id, class_name, mm_id in results:

        if family_name not in famDict:
            famDict[family_name] = {
                "value": family_name,
                "label": family_name,
                "classes": {}
            }
            data["families"].append(famDict[family_name])

        if class_id not in famDict[family_name]["classes"]:
            famDict[family_name]["classes"][class_id] = {
                "value": class_id,
                "label": class_name,
                "mmId": []
            }
        if mm_id:
            famDict[family_name]["classes"][class_id]["mmId"].append({
                "value": mm_id,
                "label": mm_id
            })
    for family in data['families']:
        family['classes'] = list(family['classes'].values())

    return {
        "status":"Success", 
        "message":"Data retrieved successfully.", 
        "data": data
    }

@app.get("/family-details")
def get_familyName(db: Session = Depends(get_db)):
    # familyName_list = db.query(Taxonomy.Family_Name).distinct().all()
    # taxonomy_data=pd.read_excel(TAXONOMY_PATH,"Taxonomy")
    description = {
        0: "The cleansing for the selected family is not yet scheduled.",
        1: "The cleansing for the selected family is currently in progress. Re-Schedulind or Cleansing request for the this family is not permitted at this time",
        2: "The cleansing for the selected family has already been scheduled. Re-Schedulind or Cleansing request for the this family is not permitted at this time",
        3: "The cleansing for the selected family was completed at the scheduled time."
    }
    # query = "select distinct tx.Family_Name as value, tx.Family_Name as label, Max(sc.Scheduled_Status) as isScheduled, sc.Scheduled_Time as date from Taxonomy as tx left join ScheduledCleansingHistory as sc on tx.Family_Name = sc.Family_Name ;"
    query = "select distinct tx.Family_Name as value, tx.Family_Name as label,sc.SCH_Id as id, sc.Scheduled_Status as isScheduled, sc.Scheduled_Time as date from Taxonomy as tx left join ScheduledCleansingHistory as sc on tx.Family_Name = sc.Family_Name where sc.Scheduled_Time = (SELECT MAX(Scheduled_Time) From ScheduledCleansingHistory where Family_Name = tx.Family_Name) OR sc.Scheduled_Time IS NULL;"
    familyCleanseStatus = pd.read_sql(query, db.bind)
    # duplicate_faqmilies = familyCleanseStatus['value'].value_counts()[familyCleanseStatus['value'].value_counts() > 1].index
    # familyCleanseStatus = familyCleanseStatus[~((familyCleanseStatus['value'].isin(duplicate_faqmilies)) & (familyCleanseStatus['isScheduled'] == 'CLEANSED'))]
    familyCleanseStatus['isScheduled'] = familyCleanseStatus['isScheduled'].apply(
                                                                        lambda x:   1 if x == 'INPROGRESS' else
                                                                                    2 if x == 'SCHEDULED'  else 
                                                                                    3 if x == 'CLEANSED' else
                                                                                    0
                                                                        )
    familyCleanseStatus['comment'] = "0: 'Not Scheduled', 1: 'INPROGRESS', 2: 'SCHEDULED', 3: 'CLEANSED'"
    familyCleanseStatus['description'] = familyCleanseStatus['isScheduled'].apply(lambda x: description.get(x, ""))
    familyCleanseStatus['disabled'] = familyCleanseStatus['isScheduled'].apply(lambda x: True if x in [1, 2] else False)
    familyCleanseStatus_dict = familyCleanseStatus.to_dict(orient = "records")

    return {
        "status":"Success", 
        "message":"family data fetched succfully", 
        "data": familyCleanseStatus_dict
    }

    # print(taxonomy_data)
    # familyName_list = taxonomy_data[['FAMILY NAME \nExxonMobil']].drop_duplicates().tolist()
    # familyName_data = [
    #     {'id': name[0], 'name': name[0]} for name in familyName_list
    #     ]
    # print(familyName_data)
    # return familyName_data


# def parse_id(id: str | None = Query(None)):
#     if id and id.startswith('[') and id.endswith(']'):
#         return json.loads(id)
#     return id



@app.post("/get-class/")
# async def getClass(family: str = None, className: str = None, id: Union[str, List[str]] = Query(None), db: Session = Depends(get_db)):
# async def getClass(family: str = None, className: str = None, id: str | List[str] = Depends(parse_id), db: Session = Depends(get_db)):
async def getClass(request: ResultRequest, db: Session = Depends(get_db)):

    family = request.family
    classId = request.classId
    id = request.mmId
    mmid_placeholder = ','.join(['?'] * len(id))
    clsid_placeholder = ','.join(['?'] * len(classId))
    if family:
        if len(classId) < 1:
            if len(id) < 1:
                query = f"select distinct cr.MM_Id AS mmId, cr.Probabilty AS confidenseScore, cr.Lang AS language, cl.Class_Name AS predictedClass, cl2.Class_Name AS currentClass, mt.Long_text AS currentLongText, mt.Short_Text AS currentShortText from ClassResult as cr left join Class as cl on cr.Class_Predicted_Id = cl.Class_Id left join MaterialText as mt on mt.MM_Id = cr.MM_Id left join Class as cl2 on mt.Class_Id = cl2.Class_Id where mt.Family_Name = ?  order by cr.MM_Id"
                params = (family,)
            else:
                query = f"select distinct cr.MM_Id AS mmId, cr.Probabilty AS confidenseScore, cr.Lang AS language, cl.Class_Name AS predictedClass, cl2.Class_Name AS currentClass, mt.Long_text AS currentLongText, mt.Short_Text AS currentShortText from ClassResult as cr left join Class as cl on cr.Class_Predicted_Id = cl.Class_Id left join MaterialText as mt on mt.MM_Id = cr.MM_Id left join Class as cl2 on mt.Class_Id = cl2.Class_Id where mt.Family_Name = ? and cr.MM_Id in ({mmid_placeholder}) order by  cr.MM_Id"
                params = (family,) + tuple(id)
        else:
            if len(id) < 1:
                # query = f"select distinct cr.MM_Id, cr.Probabilty, cr.Lang, cl.Class_Name, mt.Long_text, mt.Short_Text from CLassResult as cr left join Class as cl on cr.Class_Predicted_Id = cl.Class_Id left join MaterialText as mt on mt.MM_Id = cr.MM_Id where mt.Family_Name = ? and cl.Class_Name = ? order by cl.Class_Name, cr.MM_Id"
                query = f"select distinct cr.MM_Id AS mmId, cr.Probabilty AS confidenseScore, cr.Lang AS language, cl.Class_Name AS predictedClass, cl2.Class_Name AS currentClass, mt.Long_text AS currentLongText, mt.Short_Text AS currentShortText from ClassResult as cr left join Class as cl on cr.Class_Predicted_Id = cl.Class_Id left join MaterialText as mt on mt.MM_Id = cr.MM_Id left join Class as cl2 on mt.Class_Id = cl2.Class_Id where mt.Family_Name = ? and cr.Class_Predicted_Id in ({clsid_placeholder}) order by cr.MM_Id"

                params = (family,) + tuple(classId)
            else:
                # query = f"select distinct cr.MM_Id, cr.Probabilty, cr.Lang, cl.Class_Name, mt.Long_text, mt.Short_Text from CLassResult as cr left join Class as cl on cr.Class_Predicted_Id = cl.Class_Id left join MaterialText as mt on mt.MM_Id = cr.MM_Id where mt.Family_Name = ? and cl.Class_Name = ? and cr.MM_Id in ({mmid_placeholder}) order by cl.Class_Name, cr.MM_Id"
                query = f"select distinct cr.MM_Id AS mmId, cr.Probabilty AS confidenseScore, cr.Lang AS language, cl.Class_Name AS predictedClass, cl2.Class_Name AS currentClass, mt.Long_text AS currentLongText, mt.Short_Text AS currentShortText from ClassResult as cr left join Class as cl on cr.Class_Predicted_Id = cl.Class_Id left join MaterialText as mt on mt.MM_Id = cr.MM_Id left join Class as cl2 on mt.Class_Id = cl2.Class_Id where mt.Family_Name = ? and cr.Class_Predicted_Id in ({clsid_placeholder}) and cr.MM_Id in ({mmid_placeholder}) order by cr.MM_Id"

                params = (family,) + tuple(classId) + tuple(id)

        classificationData = pd.read_sql(query, db.bind, params=params)
        classificationData['confidenseScore'] =  (classificationData['confidenseScore'] * 100).map("{:.2f}%".format)

    # if family and className:
    #     if className == 'All':
    #         classData = db.query(Class.Class_Id, Class.Class_Name).filter(Class.Family_Name == family).all()
    #     else:
    #         classData = db.query(Class.Class_Id, Class.Class_Name).filter(Class.Family_Name == family, Class.Class_Name == className).all()
        
    #     classIds = [item[0] for item in classData]
    #     print("classIds", classIds)
    #     class_placeholders = ', '.join(['?'] * len(classIds))

    #     if id[0] == "All":
    #         query1 = f"select MM_Id, Class_Predicted_Id, Probabilty from ClassResult where Class_Predicted_Id in ({class_placeholders})"
    #         params=tuple(classIds)
    #     else:
    #         id_placeholders = ','.join(['?'] * len(id))
    #         query1 = f"select MM_Id, Class_Predicted_Id, Probabilty from ClassResult where Class_Predicted_Id in ({class_placeholders}) and MM_Id in ({id_placeholders})"
    #         params=tuple(classIds + id)
        
    #     class_prob = pd.read_sql(query1, db.bind, params=params)

    #     class_prob['Class_Name'] = class_prob['Class_Predicted_Id'].map(dict(classData))
    #     print(class_prob)
    #     mmidlist = class_prob['MM_Id'].tolist()
    #     print(mmidlist)
    #     mmid_placeholders = ','.join(['?'] * len(mmidlist))
    #     query2 = f"select MM_Id, Long_Text, Short_Text from MaterialText where Family_Name = ? and MM_Id in ({mmid_placeholders})"
    #     materialTextData = pd.read_sql(query2, db.bind, params=(family,) + tuple(mmidlist))

    #     classificationData = pd.merge(class_prob, materialTextData, on="MM_Id", how='left')
    #     classificationData = classificationData.drop(columns=['Class_Predicted_Id'])
        classificationData_dict = classificationData.to_dict(orient = 'records')

        # return classificationData_dict
        return {
            "status":"Success", 
            "message":"Data retrieved successfully.", 
            "data": classificationData_dict
        }
    
@app.post("/get-cleanseddata/")
async def getCleansedData(request: ResultRequest, db: Session = Depends(get_db)):

    family = request.family
    classId = request.classId
    id = request.mmId
    mmid_placeholder = ','.join(['?'] * len(id))
    clsid_placeholder = ','.join(['?'] * len(classId))
    if family:
        if len(classId) < 1:
            if len(id) < 1:
                query = f"select distinct cd.Family_Name AS family, cd.MM_Id AS mmId, cd.Sequence_No AS charSequenseNo, cd.Characteristic_name AS character, cd.Suggested_Value as suggestedValue, cd.Proposed_Value AS proposedValue, cd.Auto_Review AS review, cl.Class_Name AS proposedClass, chr.Current_Value AS currentValue, cl2.Class_Name AS currentClass from CleansedData as cd left join Class as cl on cd.Class_Id = cl.Class_Id left join CharacterData as chr on cd.Family_Name = chr.Family_Name and cd.MM_Id = chr.MM_Id and cd.Characteristic_name = chr.Characteristic_Name left join MaterialText as mt on mt.MM_Id = cd.MM_Id left join Class as cl2 on mt.Class_Id = cl2.Class_Id where cd.Family_Name = ?  order by cd.Family_Name, cl.Class_Name, cd.MM_Id"
                params = (family,)
            else:
                query = f"select distinct cd.Family_Name AS family, cd.MM_Id AS mmId, cd.Sequence_No AS charSequenseNo, cd.Characteristic_name AS character, cd.Suggested_Value as suggestedValue, cd.Proposed_Value AS proposedValue, cd.Auto_Review AS review, cl.Class_Name AS proposedClass, chr.Current_Value AS currentValue, cl2.Class_Name AS currentClass from CleansedData as cd left join Class as cl on cd.Class_Id = cl.Class_Id left join CharacterData as chr on cd.Family_Name = chr.Family_Name and cd.MM_Id = chr.MM_Id and cd.Characteristic_name = chr.Characteristic_Name left join MaterialText as mt on mt.MM_Id = cd.MM_Id left join Class as cl2 on mt.Class_Id = cl2.Class_Id where cd.Family_Name = ? and cd.MM_Id in ({mmid_placeholder}) order by cd.Family_Name, cl.Class_Name, cd.MM_Id"
                params = (family,) + tuple(id)
        else:
            if len(id) < 1:
                query = f"select distinct cd.Family_Name AS family, cd.MM_Id AS mmId, cd.Sequence_No AS charSequenseNo, cd.Characteristic_name AS character, cd.Suggested_Value as suggestedValue, cd.Proposed_Value AS proposedValue, cd.Auto_Review AS review, cl.Class_Name AS proposedClass, chr.Current_Value AS currentValue, cl2.Class_Name AS currentClass from CleansedData as cd left join Class as cl on cd.Class_Id = cl.Class_Id left join CharacterData as chr on cd.Family_Name = chr.Family_Name and cd.MM_Id = chr.MM_Id and cd.Characteristic_name = chr.Characteristic_Name left join MaterialText as mt on mt.MM_Id = cd.MM_Id left join Class as cl2 on mt.Class_Id = cl2.Class_Id where cd.Family_Name = ? and cd.Class_Id in ({clsid_placeholder}) order by cd.Family_Name, cl.Class_Name, cd.MM_Id"
                params = (family,) + tuple(classId)
            else:
                query = f"select distinct cd.Family_Name AS family, cd.MM_Id AS mmId, cd.Sequence_No AS charSequenseNo, cd.Characteristic_name AS character, cd.Suggested_Value as suggestedValue, cd.Proposed_Value AS proposedValue, cd.Auto_Review AS review, cl.Class_Name AS proposedClass, chr.Current_Value AS currentValue, cl2.Class_Name AS currentClass from CleansedData as cd left join Class as cl on cd.Class_Id = cl.Class_Id left join CharacterData as chr on cd.Family_Name = chr.Family_Name and cd.MM_Id = chr.MM_Id and cd.Characteristic_name = chr.Characteristic_Name left join MaterialText as mt on mt.MM_Id = cd.MM_Id left join Class as cl2 on mt.Class_Id = cl2.Class_Id where cd.Family_Name = ? and cd.Class_Id in ({clsid_placeholder}) and cd.MM_Id in ({mmid_placeholder}) order by cd.Family_Name, cl.Class_Name, cd.MM_Id"
                params = (family,) + tuple(classId) + tuple(id)
        cleansedData = pd.read_sql(query, db.bind, params=params)

        cleansedData_dict = cleansedData.to_dict(orient='records')

        return {
            "status":"Success", 
            "message":"Data retrieved successfully.", 
            "data": cleansedData_dict
        }
    
@app.post("/get-shortlongtext/")
async def getShortLongText(request: ResultRequest, db: Session = Depends(get_db)):
    
    family = request.family
    classId = request.classId
    id = request.mmId
    print(family)
    print(classId)
    print(id)

    # id = id.split(',')
    print(id)
    mmid_placeholder = ','.join(['?'] * len(id))
    clsid_placeholder = ','.join(['?'] * len(classId))
    if family:
        if len(classId) < 1:
            if len(id) < 1:
                query = f"select distinct sl.MM_Id AS mmId, sl.Family_Name AS family, sl.Propsed_Short_Text AS proposedShortText, sl.Proposed_Long_Text AS proposedLongText, mt.Long_text AS currentLongText, mt.Short_Text AS currentShortText, cl.Class_Name AS class from ShortLongText as sl left join MaterialText as mt on mt.MM_Id = sl.MM_Id left join CleansedData as cd on cd.MM_Id = sl.MM_Id left join Class as cl on cd.Class_Id = cl.Class_Id where sl.Family_Name = ?  order by sl.Family_Name, cl.Class_Name, sl.MM_Id"
                params = (family,)
            else:
                query = f"select distinct sl.MM_Id AS mmId, sl.Family_Name AS family, sl.Propsed_Short_Text AS proposedShortText, sl.Proposed_Long_Text AS proposedLongText, mt.Long_text AS currentLongText, mt.Short_Text AS currentShortText, cl.Class_Name AS class from ShortLongText as sl left join MaterialText as mt on mt.MM_Id = sl.MM_Id left join CleansedData as cd on cd.MM_Id = sl.MM_Id left join Class as cl on cd.Class_Id = cl.Class_Id where sl.Family_Name = ? and sl.MM_Id in ({mmid_placeholder}) order by sl.Family_Name, cl.Class_Name, sl.MM_Id"
                params = (family,) + tuple(id)
        else:
            if len(id) < 1:
                query = f"select distinct sl.MM_Id AS mmId, sl.Family_Name AS family, sl.Propsed_Short_Text AS proposedShortText, sl.Proposed_Long_Text AS proposedLongText, mt.Long_text AS currentLongText, mt.Short_Text AS currentShortText, cl.Class_Name AS class from ShortLongText as sl left join MaterialText as mt on mt.MM_Id = sl.MM_Id left join CleansedData as cd on cd.MM_Id = sl.MM_Id left join Class as cl on cd.Class_Id = cl.Class_Id where sl.Family_Name = ? and cl.Class_Id in ({clsid_placeholder}) order by sl.Family_Name, cl.Class_Name, sl.MM_Id"
                params = (family,) + tuple(classId)
            else:
                query = f"select distinct sl.MM_Id AS mmId, sl.Family_Name AS family, sl.Propsed_Short_Text AS proposedShortText, sl.Proposed_Long_Text AS proposedLongText, mt.Long_text AS currentLongText, mt.Short_Text AS currentShortText, cl.Class_Name AS class from ShortLongText as sl left join MaterialText as mt on mt.MM_Id = sl.MM_Id left join CleansedData as cd on cd.MM_Id = sl.MM_Id left join Class as cl on cd.Class_Id = cl.Class_Id where sl.Family_Name = ? and cl.Class_Id in ({clsid_placeholder}) and sl.MM_Id in ({mmid_placeholder}) order by sl.Family_Name, cl.Class_Name, sl.MM_Id"
                params = (family,) + tuple(classId) + tuple(id)

        slText = pd.read_sql(query, db.bind, params=params)

        slText_dict = slText.to_dict(orient='records')

        return {
            "status":"Success", 
            "message":"Data retrieved successfully.", 
            "data": slText_dict
        }
    
@app.get("/dashboard/familytree")
async def dashboardFamily(DB: Tuple[Session , Cursor]= Depends(getdb)):
    db, cursor = DB
    query1 = '''select distinct tx.Family_Name as family,tx.Class_Id, cl.Class_Name, cd.MM_Id as mmId FROM dbo.Taxonomy
         as tx left join dbo.CleansedData as cd on cd.Family_Name = tx.Family_Name and cd.Class_Id = tx.Class_Id and
         cd.Characteristic_name = tx.Characteristic_Name left join dbo.Class as cl on tx.Class_Id = cl.Class_Id;'''
    cursor.execute(query1)
    columns1 = cursor.description
    col_name1 = [col[0] for col in columns1]
    results1 = cursor.fetchall()
    results1 = pd.DataFrame.from_records(results1, columns=col_name1)

    query2  = '''select distinct tx.Class_Id, tx.Characteristic_Name as characteristic, tx.Importance as importance FROM
        dbo.Taxonomy as tx left join dbo.CleansedData as cd on cd.Family_Name = tx.Family_Name and cd.Class_Id = tx.Class_Id
          and cd.Characteristic_name = tx.Characteristic_Name left join dbo.Class as cl on tx.Class_Id = cl.Class_Id;'''

    cursor.execute(query2)
    columns2 = cursor.description
    col_name2 = [col[0] for col in columns2]
    results2 = cursor.fetchall()
    results2 = pd.DataFrame.from_records(results2, columns=col_name2)

    result_new = pd.merge(results1, results2, on = 'Class_Id')

    data={"families":[]}
    famDict = {}
    for _, (family_name, class_id, class_name, mm_id, char, imp) in result_new.iterrows():
        if family_name not in famDict:
            famDict[family_name] ={
                "value": family_name,
                "label": family_name,
                "classes": {}
            }
            data["families"].append(famDict[family_name])

        if class_id not in famDict[family_name]["classes"]:
            famDict[family_name]["classes"][class_id] = {
                "value": class_id,
                "label": class_name,
                "mmId": {},
                "char": {}
            }
        if mm_id not in famDict[family_name]["classes"][class_id]['mmId']:
            famDict[family_name]["classes"][class_id]["mmId"][mm_id] = {
                "value": mm_id,
                "label": mm_id
            }
        if char not in famDict[family_name]["classes"][class_id]["char"]:
            famDict[family_name]["classes"][class_id]["char"][char] = {
                "value": char,
                "label": char,
                "imp": []
            }
        if len(famDict[family_name]["classes"][class_id]["char"][char]["imp"]) == 0:
            famDict[family_name]["classes"][class_id]["char"][char]["imp"].append({
                "value": imp,
                "label": imp
            })

    for family in data["families"]:
        family["classes"] = list(family["classes"].values())

        for classname in family["classes"]:
            classname['mmId'] = list(classname['mmId'].values())
            classname['char'] = list(classname['char'].values())
    
    return {
        "status":"Success", 
        "message":"Data retrieved successfully.", 
        "data": data
    }   

@app.get("/dashboard/family")
async def dashboardFamilyList(db: Session = Depends(get_db)):

    query = ''' SELECT DISTINCT Family_Name as value, Family_Name as label from Taxonomy'''
    familyData = pd.read_sql(query, db.bind)
    familyDict = familyData.to_dict(orient='records')

    response = {
        "status": "Success",
        "message": "family data fetched successfully",
        "data": {"family":familyDict,
                 "selected":["VALVES/ACTUATORS/OPERATORS"]},
    }

    return response

@app.post("/dashboard/family/")
async def dashboardFamilyList(request: DashboardData, db: Session = Depends(get_db)):

    try:
        family = request.family
        classId = request.classId
        characteristics = request.characteristics
        materialID = request.materialID
        # source
        # importance = request.importance

        family_placeholder = ','.join(['?'] * len(family))

        # Query to fetch data by filtering Family name
        # Writing 2 queries as from single query the data is big taking time to fetch
        query1 = f'''select distinct cd.Class_Id, cl.Class_Name, cd.MM_Id from dbo.CleansedData as cd join dbo.Class as cl on cd.Class_Id = cl.Class_Id where cd.Family_Name in ({family_placeholder});'''
        query2 = f'''select distinct cd.Class_Id, tx.Characteristic_Name from dbo.CleansedData as cd join dbo.Taxonomy as tx on cd.Class_Id = tx.Class_Id where cd.Family_Name in ({family_placeholder});'''
        params = tuple(family)

        # Fetching data in df format
        data1 = pd.read_sql(query1, db.bind, params=params)
        data2 = pd.read_sql(query2, db.bind, params=params)

        data = pd.merge(data1, data2, on='Class_Id')

        # Filtering data based on dropdown selection
        ''' From the 3 dropdowns if the user selects an option from mmid then other two dropdowns must show only
        related class and char options but at the same time we have to show all the mmids in the mmid dropdown with 
        the one selected so single filtering the data with selected options would also filter mmid resulting in getting
        only selected option so in dropdown when user selects an option from mmid after filtering mmid dropdown will have
        only selected options therefore filtering separatly for all the three filter list'''

        data_1 = (data[data['Class_Id'].isin(classId)] if classId else data).drop('Class_Id', axis=1)
        data_2 = (data[data['MM_Id'].isin(materialID)] if materialID else data).drop('MM_Id', axis=1)
        data_3 = (data[data['Characteristic_Name'].isin(characteristics)] if characteristics else data).drop('Characteristic_Name', axis=1)

        # merging data based on common columns
        datamrg1 = pd.merge(data_1, data_2, on=['Characteristic_Name','Class_Name'], how = 'inner')

        datamrg1 = datamrg1.rename(columns={'Characteristic_Name': 'value'})
        datamrg1['label'] = datamrg1['value']
        datamrg1unique = datamrg1.drop_duplicates(subset=['value', 'label'])

        datamrg2 = pd.merge(data_2, data_3, on=['Class_Id','Class_Name'], how = 'inner')

        datamrg2 = datamrg2.rename(columns={'Class_Id': 'value'})
        datamrg2 = datamrg2.rename(columns={'Class_Name': 'label'})
        datamrg2unique = datamrg2.drop_duplicates(subset=['value', 'label'])

        datamrg3 = pd.merge(data_1, data_3, on=['MM_Id','Class_Name'], how = 'inner')

        datamrg3 = datamrg3.rename(columns={'MM_Id': 'value'})
        datamrg3['label'] = datamrg3['value']
        datamrg3unique = datamrg3.drop_duplicates(subset=['value', 'label'])

        charDict = datamrg1unique[['value', 'label']].to_dict(orient = 'records')
        classDict = datamrg2unique[['value', 'label']].to_dict(orient = 'records')
        mmidDict = datamrg3unique[['value', 'label']].to_dict(orient = 'records')

        selectedchar = []
        selectedClass = []
        selectedMMid = []
        if characteristics:
            charDict_values = set(d['value'] for d in charDict)
            selectedchar.extend(set(characteristics) & charDict_values)

        if classId:
            classDict_values = set(d['value'] for d in classDict)
            selectedClass.extend(set(classId) & classDict_values)

        if materialID:
            mmidDict_values = set(d['value'] for d in mmidDict)
            selectedMMid.extend(set(materialID) & mmidDict_values)
        
        responseData = {
                "ClassId": {
                    "data": classDict,
                    "selected": selectedClass
                },
                "characteristicsId": {
                    "data": charDict,
                    "selected": selectedchar
                },
                "materialID": {
                    "data": mmidDict,
                    "selected": selectedMMid
                }
            }
        

        response = {
            "status": "Success",
            "message": "Family items fetched successfully",
            "data": responseData
        }

        return response
    
    except Exception as e:
        print(e)
        db.rollback()
        raise HTTPException(status_code=400, detail="Something went wrong.")

@app.post("/dashboard/")
async def dashboard(request: DashboardData, DB: Tuple[Session , Cursor]= Depends(getdb)):
    db, cursor = DB
    family = request.family
    classId = request.classId
    characteristics = request.characteristics
    materialID = request.materialID
    importance = request.importance

    stored_procedure_name = '[dbo].[sp_get_dashboard]'

    param1 = ','.join(family) if family else None
    param2 = ','.join(classId) if classId else None
    param3 = ','.join(characteristics) if characteristics else None
    param4 = ','.join(materialID) if materialID else None
    param5 = None
    param6 = ','.join(importance) if importance else None

    cursor.execute(f"EXEC {stored_procedure_name} @FamilyName=?, @ClassId = ?, @CharacteristicName=?, @MMId=?, @Source=?, @Importance=?", param1, param2, param3, param4, param5, param6)

    # rows = cursor.fetchall()
    dashboardDataList = []
    while True:
        columns = [desc[0] for desc in cursor.description]
        rows = cursor.fetchall()
        resultdf = pd.DataFrame.from_records(rows, columns=columns)
        dashboardDataList.append(resultdf)
        if not cursor.nextset():
            break
    if dashboardDataList:
        materialCountdf = dashboardDataList[0]
        importanceCountdf = dashboardDataList[1]
        charImportanceCountdf = dashboardDataList[2]
        scheduleCountdf = dashboardDataList[3]

        materialCountDict = materialCountdf.to_dict(orient='records')[0]
        # importanceCountDict = importanceCountdf.to_dict(orient='records')
        charImportanceCountDict = charImportanceCountdf.to_dict(orient='records')
        scheduleCountDict = scheduleCountdf.to_dict(orient='records')[0]

        importanceCountdf['name'] = importanceCountdf['Importance'].apply(lambda x: importanceDict.get(x, 'blank'))
        importanceCountdf['value'] = importanceCountdf['MaterialCount']

        importanceCountDict = importanceCountdf[['name',	'value']].to_dict(orient='records')

        
    else:
        materialCountDict = {}
        importanceCountDict = []
        charImportanceCountDict = []
        scheduleCountDict = {}
    
    response = {
            "status": "Success",
            "message": "Dashboard data fetched successfully",
            "data": {
                "materialsCounts": materialCountDict,
                "matrialByImp": importanceCountDict,
                "countByCharAndImp": charImportanceCountDict,
                "scheduleTasks": scheduleCountDict
            }
        }
    
    return response

    
@app.get("/dashboard/family1")
async def dashboardFamily(DB: Tuple[Session , Cursor]= Depends(getdb)):
    db, cursor = DB
    query1 = '''select distinct tx.Family_Name as family,tx.Class_Id, cl.Class_Name, cd.MM_Id as mmId, tx.Characteristic_Name as characteristic,
tx.Importance as importance FROM dbo.Taxonomy as tx left join dbo.CleansedData as cd on cd.Family_Name = tx.Family_Name and
cd.Class_Id = tx.Class_Id and cd.Characteristic_name = tx.Characteristic_Name left join dbo.Class as cl on tx.Class_Id = cl.Class_Id;'''
    cursor.execute(query1)
    columns1 = cursor.description
    col_name1 = [col[0] for col in columns1]
    results1 = cursor.fetchall()
    result_new = pd.DataFrame.from_records(results1, columns=col_name1)

    data={"families":[]}
    famDict = {}
    for _, (family_name, class_id, class_name, mm_id, char, imp) in result_new.iterrows():
        if family_name not in famDict:
            famDict[family_name] ={
                "value": family_name,
                "label": family_name,
                "classes": {}
            }
            data["families"].append(famDict[family_name])

        if class_id not in famDict[family_name]["classes"]:
            famDict[family_name]["classes"][class_id] = {
                "value": class_id,
                "label": class_name,
                "mmId": {},
                "char": {}
            }
        if mm_id not in famDict[family_name]["classes"][class_id]['mmId']:
            famDict[family_name]["classes"][class_id]["mmId"][mm_id] = {
                "value": mm_id,
                "label": mm_id
            }
        if char not in famDict[family_name]["classes"][class_id]["char"]:
            famDict[family_name]["classes"][class_id]["char"][char] = {
                "value": char,
                "label": char,
                "imp": []
            }
        if len(famDict[family_name]["classes"][class_id]["char"][char]["imp"]) == 0:
            famDict[family_name]["classes"][class_id]["char"][char]["imp"].append({
                "value": imp,
                "label": imp
            })

    for family in data["families"]:
        family["classes"] = list(family["classes"].values())

        for classname in family["classes"]:
            classname['mmId'] = list(classname['mmId'].values())
            classname['char'] = list(classname['char'].values())
    
    return {
        "status":"Success", 
        "message":"Data retrieved successfully.", 
        "data": data
    }   


# @app.get("/family_name/")
# def get_familyName(db: Session = Depends(get_db)):
#     # familyName_list = db.query(Taxonomy.Family_Name).distinct().all()
#     taxonomy_data=pd.read_excel(TAXONOMY_PATH,"Taxonomy")
#     familyName_list = taxonomy_data[['FAMILY NAME \nExxonMobil']].drop_duplicates().tolist()
#     familyName_data = [
#         {'id': name[0], 'name': name[0]} for name in familyName_list
#         ]
#     return familyName_data
    
# if __name__ == "__main__":
#     uvicorn.run(app, host="0.0.0.0", port=8000)



# app = FastAPI()
# Base = declarative_base()


 
# initialise database
# Base.metadata.create_all(bind=engine)


pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto") 
# For Hash password
def hash_password(password: str) -> str:
    pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
    return pwd_context.hash(password)
 
# Create new user
def create_user(db, user_data: UserCreateRequest):
    hashed_password = hash_password(user_data.password) # Encrypt the password
    user = Users(
        EmailId = user_data.email,
        FirstName = user_data.firstName,
        LastName = user_data.lastName,
        Password = hashed_password,
        Role_Id = user_data.role[0],
        Created_By = f"{user_data.firstName} {user_data.lastName}",
        Status = StatusEnum.pending.value
    )
    db.add(user)
    db.commit()
    db.refresh(user)
 
    return user

class LoginRequest(BaseModel):
    email: str
    password: str


# login endpoint
@app.post("/auth/signin/")
def login_user(login_data: LoginRequest):
    db = SessionLocal()
    try:
        user = db.query(Users).filter(Users.EmailId == login_data.email).first()
        if not user:
            raise HTTPException(status_code=404, detail="User name does not exist.")
        
        if user.Status == StatusEnum.pending:
            raise HTTPException(status_code=403, detail="User name pending for admin approval.")
        elif user.Status == StatusEnum.rejected:
            raise HTTPException(status_code=403, detail="User name rejected by admin")
        
        if user.Status == StatusEnum.accepted:
            if not pwd_context.verify(login_data.password, user.Password):
                raise HTTPException(status_code=401, detail="Invalid passowrd.")
            return {"message":"Login successful!"}
        
    finally:
        db.close()




# Endpoint to create a new user account
@app.post("/auth/signup/")
def register_user(user_data: UserCreateRequest):
    db = SessionLocal()
    try:
        user = create_user(db, user_data)
        return {"message": "User registered successfully", "email": user.EmailId}
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=400, detail="Email already registered")
    finally:
        db.close()

# Populate data in admin page
@app.get("/users/approval")
def get_all_users():
    db = SessionLocal()
    # print("AAA")
    try:
        users = db.query(Users).all()
        data = []
        for user in users:
            userdata = {}
            userdata['firstName'] = str(user.FirstName)
            userdata['lastName'] = str(user.LastName)
            userdata['fullName'] = str(user.FirstName)+str(user.LastName)
            userdata['email'] = str(user.EmailId)
            userdata['date'] = user.Created_On
            userdata['role'] = [str(user.Role_Id)]
            userdata['status'] = str(user.Status)
            data.append(userdata)
        print(users)
        response = {
            "success": True,
            "message": "fetched Successfully",
            "data":data
        }
        return response
    # except Exception as e:
    #     print(e)
    finally:
        db.close()

#Admin Page
@app.patch("/user/approval/")
def update_user_status(user_id: uuid.UUID, status_update: UserStatusUpdateRequest):
    db = SessionLocal()
    try:
        user = db.query(Users).filter(Users.User_Id == user_id).first()
        print("user", user)
        if not user:
            raise HTTPException(status_code=404, detail="User not found")
        
        if status_update.status in [StatusEnum.accepted, StatusEnum.rejected]:
            user.Status = str(status_update.status.value)
            print(type(user.Status))
            user.Modified_By = "admin"
            db.commit()
            return {"message": f"{user.Status} Successfully"}
        else:
            raise HTTPException(status_code=400, detail="Invalid status update")
    finally:
        db.close()





@app.post("/cleanse/schedule-list/")
async def scheduleList(request: getScheduleData, DB: Tuple[Session , Cursor]= Depends(getdb)):
    try:
        db, cursor = DB
        family=request.familyID
        status=request.statusId
        familyplaceholder = ','.join(['?']*len(family)) if family else None
        statusplaceholder = ','.join(['?']*len(status)) if status else None

        query = f'''SELECT SCH_Id as id, Family_Name as family, Scheduled_Status as status, Scheduled_Progress as progress,
                Created_By as scheduleBy, Scheduled_Time as scheduleTime from ScheduledCleansingHistory WHERE 
                ({'1=1' if not family else f"Family_Name IN ({familyplaceholder})"})
                AND 
                ({'1=1' if not status else f"Scheduled_Status IN ({statusplaceholder})"})'''

        # query = f'''SELECT SCH_Id as id, Family_Name as family, Schedule_Status as status, Scheduled_Progress as progress,
        #          Created_By as scheduleBy, Scheduled_Time as scheduleTime from ScheduledCleansingHistory WHERE 
        #          (Family_Name IN ({familyplaceholder}) AND (
        #          Schedule_Status IN ({statusplaceholder}))'''
        
        param = tuple(family) + tuple(status)

        cursor.execute(query, param)
        columns = cursor.description
        col_name = [col[0] for col in columns]
        scheduledData = cursor.fetchall()
        result_new = pd.DataFrame.from_records(scheduledData, columns=col_name)

        data = result_new.to_dict(orient = 'records')

        response = {
            "status": "Success",
            "message": "Scheduled data fetched successfully",
            "data": data
        }

        return response

    except Exception as e:
        print(e)
        db.rollback()
        raise HTTPException(status_code=400, detail="Email already registered")
    
@app.get("/cleanse/schedule")
async def getScheduleDataToEdit(id: str, db: Session = Depends(get_db)):
    schData = db.query(ScheduledCleansingHistory).filter(ScheduledCleansingHistory.SCH_Id == id).first()
    
    data = {
        "id": id,
        "dateTime": schData.Scheduled_Time,
        "family": schData.Family_Name,
        "runtime": "later"
    }

    response = {
        "status": "Success",
        "message": "Scheduled Data has been fetched Successfully",
        "data": data
    }

    return response

@app.put("/cleanse/schedule/")
async def editScheduledTask(request: SchEditedData, db: Session = Depends(get_db)):
    schId = request.id
    runtime = request.runtime
    family = request.family
    current_datetime = datetime.now()
    scheduleTime = request.dateTime

    query = f'''SELECT SCH_Id as id, Family_Name as family, Scheduled_Status as status, Scheduled_Progress as progress,
                Created_By as scheduleBy, Scheduled_Time as scheduleTime from ScheduledCleansingHistory WHERE 
                SCH_Id != ? and Family_Name = ? and Scheduled_Status in (?, ?)'''
    
    data = pd.read_sql(query, db.bind, params=(schId, family, "SCHEDULED", "INPROGRESS"))

    if not data.empty:
        schStatus = data['status'][0]
        return JSONResponse( content={ "status": "Failed", "message": f"Cleansing for the family {family} is already {schStatus}. Re-Schedulind or Cleansing request for the this family is not permitted at this time"})
    else:
        local_time = scheduleTime.astimezone(pytz.timezone('Asia/Kolkata'))

        ScheduleTimeLocal = local_time.replace(tzinfo=None)

        print(ScheduleTimeLocal)
        schData = db.query(ScheduledCleansingHistory).filter(ScheduledCleansingHistory.SCH_Id == schId).update({
                                                                ScheduledCleansingHistory.Family_Name: family,
                                                                ScheduledCleansingHistory.Scheduled_Time: scheduleTime,
                                                                ScheduledCleansingHistory.Scheduled_Status: MaterialTextStatus.SCHEDULED,
                                                                ScheduledCleansingHistory.Modified_On: current_datetime.strftime('%Y-%m-%d %H:%M:%S')
                                                            })
        db.commit()

        if schData > 0:
        # generated_sch_id = str(schData.SCH_Id)
            print("runtime", runtime)
            # print("generated_sch_id", generated_sch_id)
            if runtime == "now":
                print("NOW")
                # cleanseData(family, generated_sch_id, db)
                threading.Thread(target=cleanseData, args = (family, schId, db), daemon=True).start()
                return JSONResponse(status_code=200, content={ "status": "Success", "message": f"Cleansing for the family {family} has been started"})

            else:
                return JSONResponse(status_code=200, content={ "status": "Success", "message": f"Schedule details for the family {family} has been edited Successfully"})
        else:
            return JSONResponse( content={ "status": "Failed", "message": f"Could not edit Schedule Detaild for {family}"})

 

# pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto") 
# # For Hash password
# def hash_password(password: str) -> str:
#     pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
#     return pwd_context.hash(password)
 
# # Create new user
# def create_user(db, user_data: UserCreateRequest):
#     hashed_password = hash_password(user_data.password) # Encrypt the password
#     user = Users(
#         EmailId = user_data.email,
#         FirstName = user_data.first_name,
#         LastName = user_data.last_name,
#         Password = hashed_password,
#         Role_Id = user_data.role_id,
#         Created_By = f"{user_data.first_name} {user_data.last_name}",
#         Status = StatusEnum.pending.value
#     )
#     db.add(user)
#     db.commit()
#     db.refresh(user)
 
#     return user

# class LoginRequest(BaseModel):
#     email: str
#     password: str


# # login endpoint
# @app.post("/login/")
# def login_user(login_data: LoginRequest):
#     db = SessionLocal()
#     try:
#         user = db.query(Users).filter(Users.EmailId == login_data.email).first()
#         print("user", user)
#         if not user:
#             raise HTTPException(status_code=404, detail="User name does not exist.")
#         print("user.Status", user.Status)
#         print(StatusEnum.accepted)
#         print(user.Password)
#         if user.Status == StatusEnum.pending.value:
#             raise HTTPException(status_code=403, detail="User name pending for admin approval.")
#         elif user.Status == StatusEnum.rejected.value:
#             raise HTTPException(status_code=403, detail="User name rejected by admin")
        
#         if user.Status == StatusEnum.accepted.value:
#             if not pwd_context.verify(login_data.password, user.Password):
#                 print("")
#                 raise HTTPException(status_code=401, detail="Invalid passowrd.")
#             return {"message":"Login successful!"}
        
#     finally:
#         db.close()




# # Endpoint to create a new user account
# @app.post("/register/")
# def register_user(user_data: UserCreateRequest):
#     db = SessionLocal()
#     try:
#         user = create_user(db, user_data)
#         return {"message": "User registered successfully", "user_id": user.User_Id}
#     except IntegrityError:
#         db.rollback()
#         raise HTTPException(status_code=400, detail="Email already registered")
#     finally:
#         db.close()

# # Populate data in admin page
# @app.put("/users", response_model=List[UserCreateRequest])
# def get_all_users():
#     db = SessionLocal()
#     print("AAA")
#     try:
#         users = db.query(Users).all()
#         print(users)
#         return users
#     except Exception as e:
#         print(e)
#     finally:
#         db.close()

# #Admin Page
# @app.put("/users/{user_id}/status")
# def update_user_status(user_id: uuid.UUID, status_update: UserStatusUpdateRequest):
#     db = SessionLocal()
#     try:
#         user = db.query(Users).filter(Users.User_Id == user_id).first()
#         print("user", user)
#         if not user:
#             raise HTTPException(status_code=404, detail="User not found")
        
#         if status_update.status in [StatusEnum.accepted, StatusEnum.rejected]:
#             user.Status = str(status_update.status.value)
#             print(type(user.Status))
#             user.Modified_By = "admin"
#             db.commit()
#             return {"message": f"User status updated to {user.Status}"}
#         else:
#             raise HTTPException(status_code=400, detail="Invalid status update")
#     finally:
#         db.close()




# @app.post("/cleanse/schedule-list/")
# async def scheduleList(request: getScheduleData, DB: Tuple[Session , Cursor]= Depends(getdb)):
#     try:
#         db, cursor = DB
#         family=request.familyID
#         status=request.statusId
#         familyplaceholder = ','.join(['?']*len(family)) if family else None
#         statusplaceholder = ','.join(['?']*len(status)) if status else None

#         query = f'''SELECT SCH_Id as id, Family_Name as family, Scheduled_Status as status, Scheduled_Progress as progress,
#                 Created_By as scheduleBy, Scheduled_Time as scheduleTime from ScheduledCleansingHistory WHERE 
#                 ({'1=1' if not family else f"Family_Name IN ({familyplaceholder})"})
#                 AND 
#                 ({'1=1' if not status else f"Scheduled_Status IN ({statusplaceholder})"})'''

#         # query = f'''SELECT SCH_Id as id, Family_Name as family, Schedule_Status as status, Scheduled_Progress as progress,
#         #          Created_By as scheduleBy, Scheduled_Time as scheduleTime from ScheduledCleansingHistory WHERE 
#         #          (Family_Name IN ({familyplaceholder}) AND (
#         #          Schedule_Status IN ({statusplaceholder}))'''
        
#         param = tuple(family) + tuple(status)

#         cursor.execute(query, param)
#         columns = cursor.description
#         col_name = [col[0] for col in columns]
#         scheduledData = cursor.fetchall()
#         result_new = pd.DataFrame.from_records(scheduledData, columns=col_name)

#         data = result_new.to_dict(orient = 'records')

#         response = {
#             "status": "Success",
#             "message": "Scheduled data fetched successfully",
#             "data": data
#         }

#         return response

#     except Exception as e:
#         print(e)
#         db.rollback()
#         raise HTTPException(status_code=400, detail="Email already registered")
    
# @app.get("/cleanse/schedule/{SCH_Id}")
# async def getScheduleDataToEdit(SCH_Id: str, db: Session = Depends(get_db)):
#     schData = db.query(ScheduledCleansingHistory).filter(ScheduledCleansingHistory.SCH_Id == SCH_Id).first()
    
#     data = {
#         "id": SCH_Id,
#         "dateTime": schData.Scheduled_Time,
#         "family": schData.Family_Name,
#         "runtime": "later"
#     }

#     response = {
#         "status": "Success",
#         "message": "Scheduled Data has been fetched Successfully",
#         "data": data
#     }

#     return response

# @app.put("/cleanse/schedule/")
# async def editScheduledTask(request: SchEditedData, db: Session = Depends(get_db)):
#     schId = request.id
#     runtime = request.runtime
#     family = request.family
#     current_datetime = datetime.now()
#     scheduleTime = request.dateTime

#     query = f'''SELECT SCH_Id as id, Family_Name as family, Scheduled_Status as status, Scheduled_Progress as progress,
#                 Created_By as scheduleBy, Scheduled_Time as scheduleTime from ScheduledCleansingHistory WHERE 
#                 SCH_Id != ? and Family_Name = ? and Scheduled_Status in (?, ?)'''
    
#     data = pd.read_sql(query, db.bind, params=(schId, family, "SCHEDULED", "INPROGRESS"))

#     if not data.empty:
#         schStatus = data['status'][0]
#         return JSONResponse( content={ "status": "Failed", "message": f"Cleansing for the family {family} is already {schStatus}. Re-Schedulind or Cleansing request for the this family is not permitted at this time"})
#     else:
#         local_time = scheduleTime.astimezone(pytz.timezone('Asia/Kolkata'))

#         ScheduleTimeLocal = local_time.replace(tzinfo=None)

#         print(ScheduleTimeLocal)
#         schData = db.query(ScheduledCleansingHistory).filter(ScheduledCleansingHistory.SCH_Id == schId).update({
#                                                                 ScheduledCleansingHistory.Family_Name: family,
#                                                                 ScheduledCleansingHistory.Scheduled_Time: scheduleTime,
#                                                                 ScheduledCleansingHistory.Scheduled_Status: MaterialTextStatus.SCHEDULED,
#                                                                 ScheduledCleansingHistory.Modified_On: current_datetime.strftime('%Y-%m-%d %H:%M:%S')
#                                                             })
#         db.commit()

#         if schData > 0:
#         # generated_sch_id = str(schData.SCH_Id)
#             print("runtime", runtime)
#             # print("generated_sch_id", generated_sch_id)
#             if runtime == "now":
#                 print("NOW")
#                 # cleanseData(family, generated_sch_id, db)
#                 threading.Thread(target=cleanseData, args = (family, schId, db), daemon=True).start()
#                 return JSONResponse(status_code=200, content={ "status": "Success", "message": f"Cleansing for the family {family} has been started"})

#             else:
#                 return JSONResponse(status_code=200, content={ "status": "Success", "message": f"Schedule details for the family {family} has been edited Successfully"})
#         else:
#             return JSONResponse( content={ "status": "Failed", "message": f"Could not edit Schedule Detaild for {family}"})



    
    














































#########################################################################################################################################################################################################################################################
#########################################################################################################################################################################################################################################################






# st.set_page_config(layout="wide")
# with st.container(border=True):
#     logo, page_title = st.columns(2)
#     with logo:
#         st.image(quest_logo)
#     with page_title:
#         st.markdown("<h1 style='text-align: left; color: purple;'>Material Management</h1>", unsafe_allow_html=True)

# option = st.selectbox(
#     "Choose Your Option",
#     ("Select","Single Material", "Bulk Material"), placeholder="Select your choice...")

# if option=='Single Material':
#     formatted_results=pd.DataFrame()
#     fillrate_df=pd.DataFrame()
#     with st.container(border=True):
#         input_data_side,results_side=st.columns(2)
    
#     with input_data_side:
#         long_text=st.text_area("Long Text",placeholder="Write material long text here...",height=300)
#         short_text=st.text_area("Short Text",placeholder="Write material short text here...")
        
#         if st.button("Find Class"):
        
#             text_items=[]
            
#             if long_text:
#                 text_items.append(long_text)
            
#             if short_text:
#                 text_items.append(short_text)
                
#             material_text='. '.join(text_items)
            
#             # cleaned_text=get_clean_text(material_text)
#             mm_lang,material_class, confidence_score=get_class(material_text)
            
#             if confidence_score>=0.45:
#                 st.session_state['s_class']=material_class
#                 st.session_state['mm_lang']=mm_lang
#                 st.markdown(f"<h4 style='text-align: left; color: green;'>CLASS PREDICTED: {material_class}</h4>", unsafe_allow_html=True)
#                 st.markdown(f"<h4 style='text-align: left; color: green;'>LANGUAGE DETECTED: {mm_lang}</h4>", unsafe_allow_html=True)
#             else:
#                 st.session_state['s_class']=None
#                 st.markdown(f"<h4 style='text-align: left; color: green;'>CLASS PREDICTED: UNDEFINED</h4>", unsafe_allow_html=True)
#                 st.markdown(f"<h4 style='text-align: left; color: green;'>LANGUAGE DETECTED: {mm_lang}</h4>", unsafe_allow_html=True)
                
#         if ('s_class' in st.session_state) and st.session_state['s_class'] and st.button("Cleanse Material"):
            
#             custom_functions=get_custom_function(st.session_state['s_class'])
#             long_llm_resp=None

#             #st.write(custom_functions)
            
#             if long_text and st.session_state['mm_lang']=='ENGLISH':
#                 clean_long_text=clean_text(long_text)
#                 st.session_state['s_text']=clean_long_text
#                 clean_long_text=clean_long_text.replace('*', ' ')
#                 try:
#                     long_llm_resp=get_llm_response(clean_long_text,custom_functions, st.session_state['s_class'])
#                 except Exception as err:
#                     #st.write(err)
#                     long_llm_resp={}
#             else:
#                 long_llm_resp={}
#             #st.write(long_llm_resp)
#             # if short_text:
#             #     clean_short_text=clean_text(short_text)
#             #     short_llm_resp=get_llm_response(clean_short_text,custom_functions)
#             #     if short_llm_resp:
#             #         for sk,sv in short_llm_resp.items():
#             #             if sk not in long_llm_resp:
#             #                 long_llm_resp[sk]=sv
#             st.session_state['llm_resp']=long_llm_resp
        
#         if ('llm_resp' in st.session_state) and st.button("Show Results"):
#             try:
#                 formatted_results=format_results(12345,st.session_state['s_text'],st.session_state['s_class'],st.session_state['llm_resp'])
#                 formatted_results['Current Long Text']=st.session_state['s_text']
#                 formatted_results=formatted_results.rename(columns={'CLASS':'CLASS_PRED'})
#                 formatted_results=formatted_results[['Item_No', 'Current Long Text', 'CLASS_PRED', 'CHAR_SEQ_NO',  'CHAR', 'CHAR VALUES','STAND CHAR VALUES']]
#                 formatted_results1=post_process(formatted_results)
#                 fillrate_df=get_fill_rate_details(formatted_results1)
#             except:
#                 st.write("Invalid Class or Text")
#     with results_side:
#         st.markdown("<h4 style='text-align: left; color: grey;'>Cleansing Results:</h4>", unsafe_allow_html=True)
#         if formatted_results.shape[0]:
#             st.dataframe(formatted_results1.style.map(review_fill_color, subset=['REVIEW']),hide_index=True)
            
#         st.markdown("<h4 style='text-align: left; color: grey;'>Short Text:</h4>", unsafe_allow_html=True)
#         if formatted_results.shape[0]:
#             cleaned_std_data_dict={row['CHAR']:row['STAND CHAR VALUES'] for ind,row in formatted_results1.iterrows() if row['CHAR']!='ADDITIONAL_DETAIL'}
#             st_generated=st_text_generate(cleaned_std_data_dict, st.session_state['s_class'])
#             st.dataframe(pd.DataFrame([(12345,st.session_state['s_text'],st.session_state['s_class'],st_generated)],columns=['Item_No','Long Text','CLASS_PRED','ST GENERATED']),hide_index=True)
        
#         st.markdown("<h4 style='text-align: left; color: grey;'>Fill Rate:</h4>", unsafe_allow_html=True)
#         if fillrate_df.shape[0]:
#             st.dataframe(fillrate_df.style.map(fill_rate_color, subset=['FILL_RATE']),hide_index=True)
        
    
# if option=='Bulk Material':
#     uploaded_file=st.file_uploader("Upload Input File",type=['xlsx','xls','csv'])
    
#     if uploaded_file:
#         file_name=uploaded_file.name
#         file_type=file_name.split(".")[-1]
        
#         if file_type=='csv':
#             test_data=pd.read_csv(os.path.join(INPUT_FOLDER, file_name))
#         else:
#             test_data=pd.read_excel(os.path.join(INPUT_FOLDER, file_name),"INPUT_DATA")
            
#         test_data=test_data[['Item_No','long_text','short_text']]
            
#     if uploaded_file is not None and st.button("Show Data"):
#         st.dataframe(test_data,width=1700,height=700)
    
#     if uploaded_file is not None and st.button("Get Classes"):
#         test_data['LONG TEXT']=test_data.apply(lambda x: str(x['long_text'])+'. '+str(x['short_text']) if x['short_text'] else str(x['long_text']), axis=1)
        
#         #test_data['cleaned_text']=test_data['LONG TEXT'].apply(get_clean_text)
        
#         test_data[['LANG','CLASS_PRED','Confidence_Score']]=test_data['LONG TEXT'].apply(get_class)
#         test_data.to_csv(os.path.join(RESULTS_PATH,"classification_results.csv"),index=False)
#         test_data=test_data.drop(columns=['LONG TEXT'])
        
#         #test_data['CLASS_GT']=test_data['Item_No'].apply(lambda x: gt_data_dict.get(x))
#         #cr=classification_report(test_data['CLASS_GT'],test_data['CLASS_PRED'],output_dict=True)
#         #cr_df=format_classification_report(cr)
#         with st.container(border=True):
#             try:
#                 st.markdown("<h5 style='text-align: center; color: black;'>Class Prediction Distribusion</h5>", unsafe_allow_html=True)
#                 chart_data=pd.DataFrame([(k,v) for k,v in dict(test_data['CLASS_PRED'].value_counts()).items()],columns=["CLASS PRED","COUNT"])
#                 chart=alt.Chart(chart_data).mark_bar().encode(
#                     x="CLASS PRED:O",
#                     y='COUNT:Q'
#                 ).properties(height=500,width=1200)
#                 st.altair_chart(chart)
#             except:
#                 pass
        
#         st.markdown("<h4 style='text-align: left; color: black;'>Class Prediction Results:</h4>", unsafe_allow_html=True)
#         #test_data=test_data.drop(columns=["CLASS_GT"])
#         st.dataframe(test_data,width=1700,height=700)
#         st.session_state['pred_class_data']=test_data
        
#     if 'pred_class_data' in st.session_state and st.button("Cleanse Material"):
#         prg = st.progress(0)
#         sample_input=st.session_state['pred_class_data']
#         #sample_input['CLASS_PRED']='COMPONENT:VALVE'
#         sample_input=sample_input[(sample_input['Confidence_Score']>=0.45) & (sample_input['CLASS_PRED']!='MECHANICAL_MACHINERY_FAMILY') & (sample_input['LANG']=='ENGLISH')].copy()
#         if sample_row_size<=sample_input.shape[0]:
#             sample_input=sample_input.sample(n=sample_row_size).copy()
#         rowcount=sample_input.shape[0]
#         formatted_results_all=[]
#         count=0.0
#         for ind,row in sample_input.iterrows():
#             count=count+1
#             try:
#                 custom_functions=get_custom_function(row['CLASS_PRED'])
#                 long_text_cleaned=None
#                 long_text_llm_resp={}
#                 if row['long_text']:
#                     long_text_cleaned=clean_text(str(row['long_text']))
#                     long_text_cleaned=long_text_cleaned.replace('*',' ')
#                     long_text_llm_resp=get_llm_response(long_text_cleaned,custom_functions, row['CLASS_PRED'])
                
#                 # if row['short_text']:
#                 #     short_text_cleaned=clean_text(str(row['short_text']))
#                 #     short_llm_resp=get_llm_response(short_text_cleaned,custom_functions)
#                 #     if short_llm_resp:
#                 #         for sk, sv in short_llm_resp.items():
#                 #             if sk not in long_text_llm_resp:
#                 #                 long_text_llm_resp[sk]=sv
                    
#                 formatted_results=format_results(row['Item_No'],long_text_cleaned,row['CLASS_PRED'],long_text_llm_resp)
#                 formatted_results_all.append(formatted_results)
#                 per_completed=int((count/rowcount)*100)
#                 prg.progress(per_completed, text=f'{per_completed}%')
#             except Exception as err:
#                 print(f"Not Cleansed:{row['Item_No']}")
#                 formatted_results=format_results(row['Item_No'],long_text_cleaned,row['CLASS_PRED'],{})
#                 formatted_results_all.append(formatted_results)
#         formatted_results_df=pd.concat(formatted_results_all)
#         st.session_state['bulk_cleanse_result']=formatted_results_df
#     if 'bulk_cleanse_result' in st.session_state and st.button("Show Results"):
#         pred_class_data=st.session_state['pred_class_data']
#         class_results=pred_class_data.rename(columns={"long_text":"Current Long Text","Confidence_Score":"PRED_CLASS_CONFIDENCE"})
#         bulk_cleanse_results=st.session_state['bulk_cleanse_result']
#         merged_results=pd.merge(bulk_cleanse_results,class_results,left_on=['Item_No'],right_on=['Item_No'],how='left')
#         merged_results=merged_results[['Item_No', 'Current Long Text', 'CLASS_PRED','PRED_CLASS_CONFIDENCE', 'CHAR_SEQ_NO',  'CHAR', 'CHAR VALUES','STAND CHAR VALUES']]
#         post_process_df=post_process(merged_results)
        
#         bulk_fill_rate_df=get_fill_rate_details(post_process_df)
#         with st.container(border=True):
#             st.markdown("<h4 style='text-align: left; color: black;'>Fill Rate Report</h4>", unsafe_allow_html=True)
#             table, plot = st.columns(2)
#             with table:
#                 st.table(bulk_fill_rate_df.style.map(fill_rate_color,subset=['FILL_RATE']))
#                 st.image(ledger_img,width=150)
#             with plot:
#                 try:
#                     pie_fig=get_fill_rate_chart(bulk_fill_rate_df)
#                     #st.pyplot(pie_fig)
#                     st.altair_chart(pie_fig)
#                 except:
#                     pass
        
#         st.markdown("<h4 style='text-align: left; color: black;'>Cleansing Results:</h4>", unsafe_allow_html=True)
#         st.dataframe(post_process_df.style.map(review_fill_color,subset=['REVIEW']),width=2000,height=700,hide_index=True)
        
#         post_process_df_groups=post_process_df.groupby('Item_No')
        
#         st_df_rows=[]
#         for g,df in post_process_df_groups:
#             new_row={}
#             new_row['Item_No']=g
#             new_row['Current Long Text']=df['Current Long Text'].unique().tolist()[0]
#             new_row['CLASS_PRED']=df['CLASS_PRED'].tolist()[0]
#             cleaned_std_data_dict={row['CHAR']:row['STAND CHAR VALUES'] for ind,row in df.iterrows() if row['CHAR']!='ADDITIONAL_DETAIL'}
#             st_generated=st_text_generate(cleaned_std_data_dict, new_row.get('CLASS_PRED'))
#             new_row['Short Text Generated']=st_generated
#             st_df_rows.append(new_row)
            
#         st.markdown("<h4 style='text-align: left; color: black;'>Short Text Results:</h4>", unsafe_allow_html=True)
#         st.dataframe(pd.DataFrame(st_df_rows),hide_index=True)