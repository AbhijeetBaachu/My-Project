import pandas as pd
import os
from thefuzz import fuzz
import re
from chromadb import Documents, EmbeddingFunction, Embeddings
import chromadb
from llama_cpp import Llama
from openai import AzureOpenAI
import json
import random

# Load config values
with open(r'config.json') as config_file:
    config_details = json.load(config_file)
    
FAMILY=config_details.get("FAMILY")

# FAMILY_SHORT=config_details.get("FAMILY_SHORT")

allow_values_size=5

def is_valve_component(text):
    valve_specifics=['SPARE FOR']
    for vs in valve_specifics:
        match=re.search(rf'(?i)\b{vs}\b',text)
        if match:
            return True
    return False

taxonomy_path='../Taxonomy'


with open(os.path.join(taxonomy_path,'char_data.json'),'r') as allow:
    all_allowables=json.load(allow)
    
with open(os.path.join(taxonomy_path,'std_data.json'),'r') as stddata:
    standardization_data=json.load(stddata)


default_chars=['MANUFACTURER_PART_NUMBER_MME','ADDITIONAL_DETAIL']
FINITE_CHARS=['API_TRIM_NUMBER_MME','BALL_TYPE_MME','GEMS_ID_MME','PHASE_MME','SCHEDULE_MME','ANGLE_MME','FINISH_MME','RADIUS_MME','FLANGE_FACING_MME','THREAD_TYPE_MME','RUN_SIZE_MME','OUTLET_SIZE_MME']
NUMERICAL_CHARS=['NOMINAL_RUN_SIZE_MME',
                 'PIPE_SIZE_MME',
                 'OUTSIDE_DIAMETER_MME',
                 'NUMBER_OF_BOLTS_MME',
                 'RADIUS_MME',
                 'PRESSURE_RATING_MME',
                 'THICKNESS_MME',
                 'NUMBER_OF_BOLT_HOLES_MME',
                 'SIZE_MME',
                 'DASH_NUMBER_MME',
                 'BOLT_CIRCLE_DIAMETER_MME',
                 'INSIDE_DIAMETER_MME',
                 'GASKET_NUMBER_MME',
                 'RIB_WIDTH_MME',
                 'SEAL_INSIDE_DIAMETER_MME',
                 'ORIFICE_SIZE_MME',
                 'SEAL_THICKNESS_MME',
                 'TEMPERATURE_RATING_MME',
                 'INNER_RING_INSIDE_DIAMETER_MME',
                 'RUN_SIZE_MME',
                 'WIDTH_MME',
                 'FOR_VALVE_SIZE_MME',
                 'LENGTH_MME']

pre_suf_data=pd.read_excel(os.path.join(taxonomy_path,'Prefix_sufix.xlsx'))
pre_suf_data.fillna('',inplace=True)

pre_suf_dict={}
for ind, row in pre_suf_data.iterrows():
    pre_suf_dict[row['CHAR']]=(row['Prefix'],row['Suffix'])

abbre_data=pd.read_excel(os.path.join(taxonomy_path,'taxonomy_abb.xlsx'))
abbre_data.dropna(subset=['WORD'],inplace=True)
abbre_data.fillna('',inplace=True)

abbre_data_dict={}
for ind, row in abbre_data.iterrows():
    abbre_data_dict[row['WORD']]=row['ABBREVIATION']
    
def get_matches_from_allowable_values(char,char_val):
    if char_val[0] in all_allowables.get(char,[]):
        return char_val[1], True
    else:
        return char_val[1], False

def clean_data_cleansed_data(cleansed_data):
    clean_dict={}
    for k,v in cleansed_data.items():
        if str(v[0]) in ['','NaN','UNKNOWN',None,'None','N/A','nan']:
            clean_dict[k]=(v[0],'NOT FOUND')
            continue
            
        corr_val,val_status=get_matches_from_allowable_values(k,v)
        
        if corr_val and val_status:
            clean_dict[k]=(corr_val,'PASSED')
        elif k in default_chars:
            clean_dict[k]=(corr_val,'PASSED')
        else:
            clean_dict[k]=(v[1],'REVIEW REQUIRED')
    return  clean_dict   

def st_text_generate(cleansed_data,class_name):
    st_text_list=[]
    cls_st_tks=[]
    class_tks=class_name.split(':')
    for ct in class_tks:
        cls_st_tks.append(abbre_data_dict.get(ct,''))
    cls_st_tks=[ele for ele in cls_st_tks if ele]
    st_text_list.append(':'.join(cls_st_tks))
    for k,v in cleansed_data.items():
        #v=v[0]
        ps_data=pre_suf_dict.get(k)
        if str(v).startswith('NPS '):
            v=(v.replace('NPS ','')+' IN').strip()
        abb_data=abbre_data_dict.get(v)
        st=''
        if abb_data and ps_data:
            st=' '.join([ps_data[0],abb_data,ps_data[1]]).strip()
        elif abb_data:
            st=abb_data
            
        if len(';'.join(st_text_list))+len(st)+1<=40:
            if st:
                st_text_list.append(st)
        else:
            return ';'.join(st_text_list)
    return ';'.join(st_text_list)

def get_char_data(char):
    char_data=[]
    char_tokens=char.split("_")
    if char_tokens[-1]=='MME':
        char_data.append(' '.join(char_tokens[:-1]))
        char_data.append('_'.join(char_tokens[:-1]))
    else:
        char_data.append(' '.join(char_tokens))
        char_data.append('_'.join(char_tokens))
    char_data.append(char)
    return list(set(char_data))

def is_key_present(long_text,key):
    keys=[]
    if key == 'GEMS_ID_MME':
        keys=['GEMS CODE','GEMS ID','GEMS SPEC','VALVE CODE']
    else:
        keys=get_char_data(key)
    for k in keys:
        match=re.search(rf'\b{re.escape(k)}\b',long_text)
        if match:
            return True, k
    return False, None

def finite_char_clean(char_val,char):
    char_values=all_allowables.get(char,[])
    for atn in char_values:
        match=re.search(rf'\b{re.escape(atn)}\b',char_val)
        if match:
            cv=match.group()
            match_found=standardization_data.get(f"{char}::{cv}",None)
            if match_found:
                return pd.Series([cv,match_found])
            else:
                return pd.Series([cv,cv])
    return pd.Series(['',''])

    
# Intializing Azure OpenAI
client = AzureOpenAI(
    api_key=config_details.get("AZURE_OPENAI_API_KEY"),  
    api_version="2024-05-01-preview",
    azure_endpoint = config_details.get("AZURE_OPENAI_ENDPOINT")
    )


def get_miss_attri_data(long_text,query):
    ans='UNKNOWN'
    user_prompt=f"""CONTEXT:'''{long_text}'''
    ATTRIBUTE: {query}
    ANSWER:..
    """
    messages=[{"role":"system", "content":"You are a helpful assistant, provide attribute value from given context in triple quotes, provide 'UNKNOWN' if no value found"},
                  {"role":"user", "content":user_prompt}]
    response=client.chat.completions.create(
        model=config_details.get("CHATGPT_MODEL"),
        temperature=0.0,
        messages=messages
    )
    resp_cont=response.choices[0].message.content
    try:
        resp_cont_tk=str(resp_cont).split(':')
        if ans in resp_cont_tk:
            return (ans,ans)
        elif len(resp_cont_tk)==1:
            return (resp_cont,resp_cont)
        elif len(resp_cont_tk)>1:
            ans=' '.join(resp_cont_tk[1:]).strip()
            return (ans,ans)
        else:
            return (ans,ans)
    except:
        return (ans,ans)

def Sorting(lst):
    if lst:
        lst2 = sorted(lst, key=len, reverse=True)
        return lst2
    return lst
    
def get_additional_text(text,char_values):
    additional_text=text
    sorted_char_vals=Sorting(char_values)
    for sc in sorted_char_vals:
        sc=re.sub(r'^\W*', '', sc)
        additional_text=re.sub(rf'(?i)\b{re.escape(sc)}\b', ' ', additional_text)
        additional_text=re.sub(rf'(?i)\s+{re.escape(sc)}\s+', ' ', additional_text)
        additional_text=additional_text.replace(f' {sc} ',' ')
        
    additional_text=' '.join([ele for ele in additional_text.split(' ') if (str(ele).strip()!='' and len(str(ele).strip())>1)])
    additional_text=re.sub(' +', ' ', additional_text)
    additional_text=re.sub(':+', ':', additional_text)
    additional_text.strip()
    return additional_text

def remove_xx(x):
    if 'xxxx' in str(x['CHAR VALUES']):
        return pd.Series(['',''])
    return pd.Series([x['CHAR VALUES'],x['STAND CHAR VALUES']])

def numerical_char_validate(x):
    char_val=x['CHAR VALUES']
    std_char_val=x['STAND CHAR VALUES']
    if char_val == 'UNKNOWN':
        pd.Series([char_val,std_char_val])

    match=re.search('\d+',str(char_val))
    if match:
        return pd.Series([char_val,std_char_val])
    return pd.Series(['',''])

def end_connection_valid(x):
    char_val=x['CHAR VALUES']
    std_char_val=x['STAND CHAR VALUES']
    if not char_val:
        return pd.Series([char_val,std_char_val])

    char_val=str(char_val).replace("*",' ')
    
    char_tk=char_val.split()

    req_tks=[]

    for ck in char_tk:
        if (not re.search('\d+',ck)) and (ck not in ['IN','MM','mm','in']):
            req_tks.append(ck)

    
    return pd.Series([' '.join(req_tks),' '.join(req_tks)])


def get_missing_data(row_data):
    ch_val=row_data['CHAR VALUES']
    std_val=row_data['STAND CHAR VALUES']
    char=row_data['CHAR']
    long_text=row_data['Current Long Text']
    try:
        if (not ch_val) or (str(ch_val).strip() in ['','NaN','UNKNOWN',None,'None','N/A','nan']):
            x,y=is_key_present(long_text,char)
            if x:
                cv,pv=get_miss_attri_data(long_text,y)
                match_found=standardization_data.get(f"{char}::{cv}",None)
                if match_found:
                    return pd.Series([cv,match_found])
                else:
                    return pd.Series([cv,pv])
            else:
                return pd.Series([ch_val,std_val])
        else:
            return pd.Series([ch_val,std_val])
    except:
        return pd.Series([ch_val,std_val])


def post_process(cleansing_df):
    cleansing_df[['CHAR VALUES','STAND CHAR VALUES']]=cleansing_df.apply(lambda x: finite_char_clean(str(x['CHAR VALUES']),x['CHAR']) if x['CHAR'] in  FINITE_CHARS else pd.Series([x['CHAR VALUES'],x['STAND CHAR VALUES']]),axis=1)
    
    cleansing_df[['CHAR VALUES','STAND CHAR VALUES']]=cleansing_df.apply(lambda x: remove_xx(x) if x['CHAR']!='ADDITIONAL_DETAIL' else pd.Series([x['CHAR VALUES'],x['STAND CHAR VALUES']]),axis=1)
    cleansing_df[['CHAR VALUES','STAND CHAR VALUES']]=cleansing_df.apply(lambda x: numerical_char_validate(x) if x['CHAR'] in NUMERICAL_CHARS else pd.Series([x['CHAR VALUES'],x['STAND CHAR VALUES']]),axis=1)
    cleansing_df[['CHAR VALUES','STAND CHAR VALUES']]=cleansing_df.apply(lambda x: end_connection_valid(x) if x['CHAR'] in ['END_CONNECTION_TYPE_MME'] else pd.Series([x['CHAR VALUES'],x['STAND CHAR VALUES']]),axis=1)
    
    
    cleansing_df_groups=cleansing_df.groupby('Item_No')
    
    df_rows=[]
    for g,df in cleansing_df_groups:
        df_temp=df
        cleansed_data_dict={row['CHAR']:(row['CHAR VALUES'],row['STAND CHAR VALUES']) for ind,row in df_temp.iterrows()}
        cleaned_data_dict=clean_data_cleansed_data(cleansed_data_dict)
        cleaned_std_data_df=pd.DataFrame([(k,v[0],v[1]) for k,v in cleaned_data_dict.items()],columns=['CHAR','STAND CHAR VALUES','REVIEW'])
        df_temp.drop(columns=['STAND CHAR VALUES'],inplace=True)
        
        df=pd.merge(df_temp,cleaned_std_data_df,on=['CHAR'],how='left')
        
        chars=[]
        std_chars=[]
        char_values=[]
        std_char_values=[]
        
        for ind, row in df.iterrows():
            row_dict=dict(row)
            if row_dict.get('CHAR')=='ADDITIONAL_DETAIL':
                add_text=get_additional_text(row_dict.get('Current Long Text'),chars+char_values)
                std_add_text=get_additional_text(row_dict.get('Current Long Text'),std_chars+std_char_values)
                row_dict['CHAR VALUES']=add_text
                row_dict['STAND CHAR VALUES']=add_text
            else:
                ch_val=row_dict.get('CHAR VALUES')
                std_ch_val=row_dict.get('STAND CHAR VALUES')
                if ch_val and (str(ch_val).strip() not in ['','NaN','UNKNOWN',None,'None','N/A','nan']):
                    chars.extend(get_char_data(row_dict.get('CHAR')))
                    char_values.append(str(ch_val).strip())
                
                if std_ch_val and (str(std_ch_val).strip() not in ['','NaN','UNKNOWN',None,'None','N/A','nan']):
                    std_chars.extend(get_char_data(row_dict.get('CHAR')))
                    std_char_values.append(str(std_ch_val).strip())
                    
            df_rows.append(row_dict)

    final_df=pd.DataFrame(df_rows)
    return final_df

