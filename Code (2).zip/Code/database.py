from sqlalchemy import create_engine, Column, Integer, String
from sqlalchemy.orm import sessionmaker, Session

# Database URL
DATABASE_URL = "mssql+pyodbc://mmtooladmin:Mmtool%40123@mmtool.database.windows.net/MMTool_Dev?driver=ODBC+Driver+17+for+SQL+Server"

# SQLAlchemy setup
engine = create_engine(DATABASE_URL)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)