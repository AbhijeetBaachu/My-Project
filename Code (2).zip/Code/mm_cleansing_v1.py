"""
Created on Mon Jun 24 10:15:05 2024

@author: 1041929
"""

import pickle
import os
from textblob import TextBlob
from cleantext import clean
from sklearn.metrics.pairwise import linear_kernel
import streamlit as st
from openai import AzureOpenAI
import json
import random
import pandas as pd
import re
import math
#from sklearn.metrics import classification_report
#import seaborn as sns
#import matplotlib.pyplot as plt
#from langdetect import detect 
import altair as alt
from PIL import Image
from llama_cpp import Llama
from chromadb import Documents, EmbeddingFunction, Embeddings
import chromadb
# import ast
from thefuzz import fuzz
from post_processing import post_process, is_valve_component, st_text_generate, get_missing_data


MODEL_PATH="../Models/"
INPUT_FOLDER="../Input/"
RESULTS_PATH="Results/"
TAXONOMY_PATH="../Taxonomy"
quest_logo=Image.open("images/Quest_Global_New_Logo.jpg")
ledger_img=Image.open("images/ledger.png")
allow_values_size=5
sample_row_size=1000

# Load config values
with open(r'config.json') as config_file:
    config_details = json.load(config_file)
    
FAMILY=config_details.get("FAMILY")

FAMILY_SHORT=config_details.get("FAMILY_SHORT")


with open(os.path.join(TAXONOMY_PATH,'char_data.json'),'r') as allow:
    all_allowables=json.load(allow)


CHAR_ALIASES={
    "GEMS_ID_MME":["GEMS ID","GEMS SPEC","GEMS CODE", "VALVE CODE"]
    }

CHARS_WITHOUT_STD=["MATERIAL_MME","SIZE_MME","PRESSURE_RATING_MME",'MANUFACTURER_PART_NUMBER_MME','ADDITIONAL_INFORMATION_MME','MANUFACTURER_NAME_MME']


def is_non_english_tokens_present(text):
    for nw in NON_ENGLISH_WORDS:
        matches=re.findall(rf'(?i)\b{re.escape(nw)}\b',text)
        if matches:
            return True
    return False

def get_lang(text):
    text=re.sub(r'\s+',' ',text)
    
    if is_non_english_tokens_present(text):
        return 'NON-ENGLISH'
    
    text=text.upper()
        
    x_test = lang_tfidf_model.transform([text])
    x_test = lang_selector_model.transform(x_test).astype('float32')
    preds = lang_classification_model.predict(x_test) #Returns list 
    
    return preds[0]

    
NON_ENGLISH_WORDS=['é',
'materiaal', 
'MATIERE',
'BAGUE',
'Distributeur', 
'Â',
'Ã',
'SIEGE',
'VANNE',
'emetteur',
'RICAMBI', 
'DISTRIBUTEUR',
'CONNECTEUR',
'COMMANDE',
'ACTIONNEUR',
'VALVOLE',
'EXTREMITES',
'DIAMETRE',
'FEMELLE',
'PNEUMATIQUE',
'FONTE',
'SUPERIORE',
'INFERIORE',
'Pompe']

cleanse_system_prompt="""You will be provided a material information, your task is to do cleansing for Mechanical and Materials Engineering (MME), material cleansing is a process of identifying right values for material properties described in tools.
- Understand property values from given examples and give most appropriate ones
- Do not miss values for properties
- Make sure all property values must from given input text
- You must always use function calling
"""

with open(os.path.join(TAXONOMY_PATH,'std_data.json'),'r') as stddata:
    standardization_data=json.load(stddata)
    
    
taxonomy_data=pd.read_excel(os.path.join(TAXONOMY_PATH,'taxonomy.xlsx'),"Taxonomy")
taxonomy_data=taxonomy_data[taxonomy_data['FAMILY']==FAMILY]
taxonomy_data=taxonomy_data.sort_values(by=['CLASS','SEQ NO.'])

allow_values=pd.read_csv(os.path.join(TAXONOMY_PATH,'allowable_values.csv'))

allow_values=allow_values[allow_values['FAMILY']==FAMILY]

taxonomy_data=taxonomy_data[~(taxonomy_data['CHARS'].str.contains('ADDITIONAL_DETAIL'))&(taxonomy_data['CHARS'].str.contains('MME'))].copy()
taxonomy_mand=taxonomy_data.copy()

taxonomy_groups=taxonomy_mand[['CLASS','CHARS','IS_MANDATORY']].groupby('CLASS')
chars_sq_groups=taxonomy_mand[['CLASS','CHARS','SEQ NO.']].groupby(['CLASS','CHARS'])

taxonomy_dict={g:[(row['CHARS'],row['IS_MANDATORY']) for indx,row in df.iterrows()] for g,df in taxonomy_groups}

allow_values_groups=allow_values[['CHAR','CHAR VALUES']].groupby('CHAR')

allow_values_dict={}
for g, df in allow_values_groups:
    values=df['CHAR VALUES'].tolist()
    allow_values_dict[g]=values
        
        
char_seq_dict={}
for g, df in chars_sq_groups:
    char_seq_dict[tuple(g)]=df['SEQ NO.'].tolist()[0]
    
# Intializing Azure OpenAI
client = AzureOpenAI(
    api_key=config_details.get("AZURE_OPENAI_API_KEY"),  
    api_version="2024-05-01-preview",
    azure_endpoint = config_details.get("AZURE_OPENAI_ENDPOINT")
    )


FIXED_VALUE_CHARS = ['ACTUATOR_TYPE_MME', 
                       'API_TRIM_NUMBER_MME', 
                       'APPLICATION_MME', 
                       'BALL_TYPE_MME', 
                       'BODY_BONNET_CONNECTION_MME', 
                       'BODY_CLOSURE_DESIGN_MME', 
                       'BODY_MATERIAL_STANDARD_MME', 
                       'BUTTERFLY_TYPE_MME', 
                       'CURRENT_RATING_MME', 
                       'CHECK_TYPE_MME', 
                       'CONFIGURATION_MME', 
                       'DRAWING_ITEM_NUMBER_MME', 
                       'DRAWING_NUMBER_MME', 
                       'DESIGN_SPECIFICATION_MME', 
                       'ENCLOSURE_TYPE_MME', 
                       'END_CONNECTION_TYPE_MME', 
                       'END_CONNECTION_STANDARD_MME', 
                       'EQUIPMENT_MME', 
                       'EQUIPMENT_MODEL_NUMBER_MME', 
                       'EQUIPMENT_SERIAL_NUMBER_MME', 
                       'FAIL_SAFE_OPERATION_MME', 
                       'FIRE_RATED_MME', 
                       'FLOW_COEFFICIENT_MME', 
                       'FLOW_RATING_MME', 
                       'FOR_VALVE_TYPE_MME', 
                       'FREQUENCY_MME', 
                       'GEMS_ID_MME', 
                       'INDUSTRY_STANDARD_MME', 
                       'INTERNAL_SPEC_REF_MME', 
                       'LENGTH_MME', 
                       'MATERIAL_MME', 
                       'MANUFACTURER_NAME_MME', 
                       'MANUFACTURER_PART_NUMBER_MME', 
                       'MOUNTING_TYPE_MME', 
                       'MODEL_DESIGNATION_MME', 
                       'OBTUATOR_MATERIAL_MME', 
                       'OPERATOR_MME', 
                       'ORIFICE_SIZE_MME', 
                       'PARENT_FIGURE_MODEL_NUMBER_MME', 
                       'PHASE_MME', 
                       'POWER_RATING_MME', 
                       'PORT_TYPE_MME', 
                       'PROCESS_CONNECTION_MME', 
                       'RATING_MME', 
                       'ROTATION_ANGLE_MME', 
                       'SEAT_RING_MATERIAL_MME', 
                       'SEAT_SPRING_MATERIAL_MME', 
                       'SPEED_RATING_MME', 
                       'SEAT_TYPE_MME', 
                       'STEM_SIZE_MME', 
                       'STEM_TYPE_MME', 
                       'TORQUE_RATING_MME', 
                       'TRAVEL_MME', 
                       'TRIM_MATERIAL_MME']



DEFAULT_STOP_WORDS=['SPECIAL_FEATURES',
                    'CS_SPECIFICATION',
                    '_SPECIFICATION',
                    'EQUIPMENT',
                    'FUNCTION_MM',
                    'SPECIAL_REQUIREMENT',
                    'SPECIAL FEATURES',
                    'RETAINED INFO',
                    'SPECIAL CONDITION',
                    'INDUSTRY REFERENCE',
                    'INTERNAL SPEC REF',
                    'FEATURES',
                    'VENDOR REFERENCE',
                    "INDUSTRY_STANDARD",
                    "INDUSTRY STANDARD",
                    "SHORT_NAME",
                    "SHORT NAME"
                    ]

CHAR_DICT={
    "END_CONNECTION_TYPE":"END CONNECTION",
    "MATERIAL_SPECIFICATION":"SPECIFICATION",
    "XXS":"EXTRA EXTRA STRONG",
    "INSIDE DIAMETER":"INSIDE_DIAMETER",
    "OUTSIDE DIAMETER":"OUTSIDE_DIAMETER",
    "CAGE MATERIAL":"CAGE_MATERIAL",
    "BALL MATERIAL":"BALL_MATERIAL",
    "CLOSURE TYPE":"CLOSURE_TYPE",
    "INTERNAL CLEARANCE":"INTERNAL_CLEARANCE",
    "SPEED RATING":"SPEED_RATING",
    "STATIC LOAD CAPACITY":"STATIC_LOAD_CAP",
    }

with open(os.path.join(MODEL_PATH,FAMILY_SHORT,"trained_model.pickle"), 'rb') as cls_model:
    cls_class_model=pickle.load(cls_model)

with open(os.path.join(MODEL_PATH,FAMILY_SHORT,"selector_model.pickle"), 'rb') as sel_model:
    cls_selector_model=pickle.load(sel_model)

with open(os.path.join(MODEL_PATH,FAMILY_SHORT,"tfidf_model.pickle"), 'rb') as tf_model:
    cls_tfidf_model=pickle.load(tf_model)
    
    
with open(os.path.join(MODEL_PATH,'Language',"trained_model.pickle"), 'rb') as cls_model:
    lang_classification_model=pickle.load(cls_model)

with open(os.path.join(MODEL_PATH,'Language',"selector_model.pickle"), 'rb') as sel_model:
    lang_selector_model=pickle.load(sel_model)

with open(os.path.join(MODEL_PATH,'Language',"tfidf_model.pickle"), 'rb') as tf_model:
    lang_tfidf_model=pickle.load(tf_model)


system_prompt='''Transform data based the pattern given in rule(s). Return output same as input if the rule pattern is not relevant to the input. return output in json format'''

def checkString(text):
    for ch in str(text):
        if ch.isalpha():
            return True
        
        if ch.isdigit():
            return True
    return False


def standardize_mm_data(mm_data,class_desc):
    stand_mmdata={}
    for mk,mv in mm_data.items():
        if mk not in CHARS_WITHOUT_STD:
            match_found=standardization_data.get(f"{mk}::{mv}",None)
            if match_found:
                stand_mmdata[mk]=match_found
            else:
                stand_mmdata[mk]=mv
        else:
            stand_mmdata[mk]=mv
            
    return stand_mmdata



def get_cleaned_char(char):
    feature_name=char.replace('_',' ').strip().lower()
    feature_tks=feature_name.split()
    if feature_tks[-1]=='mm':
        feature_name=' '.join(feature_tks[:-1])

    return feature_name


def get_class(text):
    
    text=text.upper()
    
    text_lang=get_lang(text)
    
    if text_lang!='ENGLISH':
        return pd.Series([text_lang, 'UNDEFINED', 0.0])
    
    if is_valve_component(text) and FAMILY=='VALVES/ACTUATORS/OPERATORS':
        return pd.Series([text_lang,'COMPONENT:VALVE', 0.99])
    

    x_test = cls_tfidf_model.transform([text])
    x_test = cls_selector_model.transform(x_test).astype('float32')
    preds = cls_class_model.predict(x_test) #Returns list 
    prob = cls_class_model.predict_proba(x_test)
    pred_class = preds[0].replace('\xa0', ' ')
    
    return pd.Series([text_lang,pred_class, float(max(prob[0]))])


# Prompts - Function calling
def create_prop_dict(class_name):
    prop_dict={}
    mand_chars=[]
    if class_name in taxonomy_dict:
        features=taxonomy_dict.get(class_name)
        class_desc=class_name
        for feature_tpl in features:
            feature=feature_tpl[0]
            #if 'Mandatory' in feature_tpl[1]:
            #mand_chars.append(feature)
            class_name_modified=' '.join([str(ele).strip() for ele in class_desc.replace(':',' ').replace('_',' ').split(',')]).lower()
            feature_name=feature.replace('_',' ').strip().lower()
            feature_tks=feature_name.split()
            if feature_tks[-1]=='mm' or feature_tks[-1]=='mme':
                feature_name=' '.join(feature_tks[:-1])
            feature_name=feature_name.upper()
            feature_name=feature_name.strip()
            mand_chars.append(feature)
            if feature in allow_values_dict:
                allow_examples=allow_values_dict.get(feature,[])
                examples=', '.join([f"{str(ele).strip()}" for ele in allow_examples[:allow_values_size]])
                if feature in CHAR_ALIASES:
                    feature_with_aliases=",".join([char_als for char_als in CHAR_ALIASES.get(feature,[])])
                    prop_dict[feature]={
                        "type":"string",
                        "description":f"{feature_with_aliases}, e.g. {examples}"    
                    }
                else:
                    prop_dict[feature]={
                        "type":"string",
                        "description":f"{feature_name}, e.g. {examples}"    
                    }
               
            else:
                examples1=all_allowables.get(feature,[])
                if examples1:
                    examples1=', '.join([f"{str(ele).strip()}" for ele in examples1[:allow_values_size]])
                    prop_dict[feature]={
                        "type":"string",
                        "description":f"{feature_name}, e.g. {examples1}"
                    }
                else:
                    prop_dict[feature]={
                        "type":"string",
                        "description":f"{feature_name}"
                    }
    return prop_dict,mand_chars

def get_custom_function(class_name):
    prop_dict,mand_chars=create_prop_dict(class_name)
    custom_functions=None
    if prop_dict:
        class_name_modified=' '.join([str(ele).strip() for ele in class_name.replace('_',' ').replace(':',' ').split(',')]).lower()
        custom_functions = [
            { "type":"function",
             "function":{
                "name": "material_cleansing",
                "description": f"{class_name_modified.upper()} material cleansing.",
                "parameters": {
                    "type": "object",
                    "properties": prop_dict
                },
                "required":mand_chars
                
                }
            }
        ]
    else:
        return None
    return custom_functions


def get_fill_rate_details(fill_df):
    fill_df=fill_df[fill_df.CHAR!='ADDITIONAL_DETAIL']
    fill_groups=fill_df.groupby('CLASS_PRED')
    fill_rate_items=[]
    for g, df in fill_groups:
        item={}
        item['CLASS']=g
        item['ITEM_COUNT']=df['Item_No'].nunique()
        item['CHAT_COUNT']=df[df['Item_No'].isin([df['Item_No'].tolist()[0]])].shape[0]
        item['CHAR_TOTAL']=df.shape[0]
        item['FILL_TOTAL']=df[(df['CHAR VALUES']!='')&(~df['CHAR VALUES'].isnull())].shape[0]
        item['FILL_RATE']=round((item['FILL_TOTAL']/item['CHAR_TOTAL'])*100,2)
        fill_rate_items.append(item)
    return pd.DataFrame(fill_rate_items)


def get_fill_rate_chart(fill_rate):
    labels = fill_rate['CLASS'].tolist()
    sizes = fill_rate['FILL_RATE'].tolist()
    source = pd.DataFrame({"category": labels, "value": sizes})

    piechart=alt.Chart(source).mark_arc().encode(
        theta="value",
        color="category"
    ).properties(height=450,width=450)
    #pie = piechart.mark_arc(outerRadius=90)
    #pie_text = piechart.mark_text(radius=110, size=20).encode(text="value:N")

    return piechart

def Sorting(lst):
    if lst:
        lst2 = sorted(lst, key=len, reverse=True)
        return lst2
    return lst

def get_additional_text(text,char_values):
    additional_text=text
    sorted_char_vals=Sorting(char_values)
    for sc in sorted_char_vals:
        sc=re.sub(r'^\W*', '', sc)
        additional_text=re.sub(rf'(?i)\b{re.escape(sc)}\b', ' ', additional_text)
        additional_text=re.sub(rf'(?i)\s+{re.escape(sc)}\s+', ' ', additional_text)
        additional_text=additional_text.replace(f' {sc} ',' ')
        
    additional_text=' '.join([ele for ele in additional_text.split(' ') if (str(ele).strip()!='' and len(str(ele).strip())>1)])
    additional_text=re.sub(' +', ' ', additional_text)
    additional_text=re.sub(':+', ':', additional_text)
    additional_text.strip()
    return additional_text


def get_clean_text(text):
    blob = TextBlob(clean(text,lower=False))
    return ' '.join(list(blob.noun_phrases))

def get_confidence_score(score):
    sim_score=1-score
    confidence_score=round(((math.pi-math.acos(sim_score))/math.pi)*100,2)
    return confidence_score


def clean_text(text):
    delimiters = [";"]
    text=', '.join([ele.strip() for ele in text.split(',')])
    for dl in delimiters:
        text=', '.join([ele.strip() for ele in text.split(dl)])
        
    text=re.sub(r'^\W*', '', text)
    text=re.sub(' +', ' ', text)
    text=text.strip()
    
    return text

def get_llm_response(text,custom_functions, class_name):
    messages=[{"role":"system", "content":cleanse_system_prompt},
              {"role":"user", "content":text}]
    response=client.chat.completions.create(
        model=config_details.get("CHATGPT_MODEL"),
        seed=42,
        temperature=0.0,
        messages=messages,
        tools=custom_functions,
        tool_choice={"type": "function", "function": {"name": "material_cleansing"}}
    )

    raw_results1=response.choices[0].message.tool_calls[0].function.arguments

    # raw_results = ast.literal_eval(raw_results)
    raw_results1= json.loads(raw_results1)
    
    
    raw_results={}
    for key,val in raw_results1.items():
        #raw_results[f"{key.replace(' ','_')}_MME"]=val
        raw_results[key]=val
        

    # st.write(raw_results)

    # raw_results = json.dumps(raw_results)
    # results_json= json.loads(raw_results)
    # return results_json
    return raw_results


def format_results(item_no,text,m_class,results_json):
    char_values=DEFAULT_STOP_WORDS
    for cls_tks in m_class.split(":"):
        char_values.append(cls_tks)
    char_seq_numbers=[]
    results_list=[]
    stand_mm_data={}
    try:
        stand_mm_data=standardize_mm_data(results_json,m_class)
    except:
        pass
    #st.write(stand_mm_data)
    for char in [char_tpl[0] for char_tpl in taxonomy_dict.get(m_class,[])]:
        res_dict={}
        res_dict['Item_No']=item_no
        res_dict['CLASS']=m_class
            
        if char in results_json:
            if results_json.get(char,'') not in ['','N/A','UNKNOWN','None']:
                
                char_tokens=char.split("_")
                if char_tokens[-1]=='MME':
                    char_values.append("_".join(char_tokens[:-1]))
                    char_values.append(" ".join(char_tokens[:-1]))
                
                res_dict['CHAR_SEQ_NO']=char_seq_dict.get((m_class,char),None)
                res_dict['CHAR']=char
                res_dict['CHAR VALUES']=results_json.get(char,'')
                
                if char in stand_mm_data:
                    res_dict['STAND CHAR VALUES']=stand_mm_data.get(char,'')
                else:
                    res_dict['STAND CHAR VALUES']=results_json.get(char,'')
                
                if res_dict['CHAR_SEQ_NO']:
                    char_seq_numbers.append(int(res_dict['CHAR_SEQ_NO']))
                #res_dict['CHAR VALUES']=results_json.get(char,{}).get("ENTITY",'')
                #res_dict['CONFIDENCE_LEVEL']=results_json.get(char,{}).get("SCORE",0.0)
                char_values.append(res_dict['CHAR VALUES'])
                if res_dict['CHAR VALUES'] in CHAR_DICT:
                    char_values.append(CHAR_DICT.get(res_dict['CHAR VALUES']))
                char_values.append(char)
                char_values.append(char.replace(' ','_'))
                if char in CHAR_DICT:
                    char_values.append(CHAR_DICT.get(char))
                char_values.append(get_cleaned_char(char))
            else:
                res_dict['CHAR_SEQ_NO']=char_seq_dict.get((m_class,char),None)
                res_dict['CHAR']=char
                res_dict['CHAR VALUES']=''
                res_dict['STAND CHAR VALUES']=''
                if res_dict['CHAR_SEQ_NO']:
                    char_seq_numbers.append(int(res_dict['CHAR_SEQ_NO']))
        else:
            res_dict['CHAR_SEQ_NO']=char_seq_dict.get((m_class,char),None)
            res_dict['CHAR']=char
            res_dict['CHAR VALUES']=''
            res_dict['STAND CHAR VALUES']=''
            if res_dict['CHAR_SEQ_NO']:
                char_seq_numbers.append(int(res_dict['CHAR_SEQ_NO']))
               
        results_list.append(res_dict)
    print("char_seq_numbers", char_seq_numbers)
    char_values=[ele for ele in char_values if ele]
    additional_text = get_additional_text(text,char_values)
    #st.write(res_dict)
    if additional_text:
        res_dict={}
        res_dict['Item_No']=item_no
        res_dict['CLASS']=m_class
        res_dict['CHAR_SEQ_NO']=max(char_seq_numbers)+1
        res_dict['CHAR']='ADDITIONAL_DETAIL'
        res_dict['CHAR VALUES']=additional_text.strip()
        res_dict['STAND CHAR VALUES']=additional_text.strip()
        results_list.append(res_dict)
    formated_result_df=pd.DataFrame(results_list)
    return formated_result_df

def fill_rate_color(val):
    if val>=75:
        color = 'lime' 
    elif val>=50:
        color='yellow'
    else:
        color='pink'
    return f'background-color: {color}'

def review_fill_color(val):
    if val=='PASSED':
        color = 'lime'
    elif val=='NOT FOUND':
        color = 'yellow'
    else:
        color='pink'
    return f'background-color: {color}'


def format_classification_report(cr):
    for k,v in cr.items():
        if k=='accuracy':
            cr[k]=round(cr[k]*100,2)
        else:
            for ak,av in v.items():
                if ak=='support':
                    cr[k][ak]=int(cr[k][ak])
                else:
                    cr[k][ak]=round(cr[k][ak]*100,2)
    
    cf_df=pd.DataFrame(cr)
    cf_df_tran=cf_df.transpose()
    cf_df_tran=cf_df_tran.round(decimals=2)
    cf_df_tran['support']=cf_df_tran['support'].astype(int)
    cf_df_tran=cf_df_tran.rename(columns={'precision':'Pression (%)', 'recall':'Recall (%)', 'f1-score':'F1 (%)','support':'MM Count'})
    return cf_df_tran
    

st.set_page_config(layout="wide")
with st.container(border=True):
    logo, page_title = st.columns(2)
    with logo:
        st.image(quest_logo)
    with page_title:
        st.markdown("<h1 style='text-align: left; color: purple;'>Material Management</h1>", unsafe_allow_html=True)

option = st.selectbox(
    "Choose Your Option",
    ("Select","Single Material", "Bulk Material"), placeholder="Select your choice...")

if option=='Single Material':
    formatted_results=pd.DataFrame()
    fillrate_df=pd.DataFrame()
    cleanse_data_status=False
    with st.container(border=True):
        input_data_side,results_side=st.columns(2)
    
    with input_data_side:
        long_text=st.text_area("Long Text",placeholder="Write material long text here...",height=300)
        short_text=st.text_area("Short Text",placeholder="Write material short text here...")
        
        if st.button("Find Class"):
        
            text_items=[]
            
            if long_text:
                text_items.append(long_text)
            
            if short_text:
                text_items.append(short_text)
                
            material_text='. '.join(text_items)
            
            # cleaned_text=get_clean_text(material_text)
            mm_lang,material_class, confidence_score=get_class(material_text)
            
            st.session_state['s_class']=material_class
            st.session_state['mm_lang']=mm_lang
            
            if confidence_score>=0.45:
                st.markdown(f"<h4 style='text-align: left; color: green;'>CLASS PREDICTED: {material_class}</h4>", unsafe_allow_html=True)
                st.markdown(f"<h4 style='text-align: left; color: green;'>LANGUAGE DETECTED: {mm_lang}</h4>", unsafe_allow_html=True)
            else:
                st.session_state['s_class']=None
                st.markdown(f"<h4 style='text-align: left; color: green;'>CLASS PREDICTED: UNDEFINED</h4>", unsafe_allow_html=True)
                st.markdown(f"<h4 style='text-align: left; color: green;'>LANGUAGE DETECTED: {mm_lang}</h4>", unsafe_allow_html=True)
                
        if ('s_class' in st.session_state) and st.session_state['s_class'] and st.button("Cleanse Material"):
            
            custom_functions=get_custom_function(st.session_state['s_class'])
            long_llm_resp=None

            if long_text and st.session_state['mm_lang']=='ENGLISH':
                clean_long_text=clean_text(long_text)
                st.session_state['s_text']=clean_long_text
                clean_long_text=clean_long_text.replace('*', ' ')
                try:
                    long_llm_resp=get_llm_response(clean_long_text,custom_functions, st.session_state['s_class'])
                except Exception as err:
                    #st.write(err)
                    long_llm_resp={}
            else:
                long_llm_resp={}
                
            st.session_state['llm_resp']=long_llm_resp
            
            formatted_results=format_results(12345,st.session_state['s_text'],st.session_state['s_class'],st.session_state['llm_resp'])
            formatted_results['Current Long Text']=st.session_state['s_text']
            formatted_results=formatted_results.rename(columns={'CLASS':'CLASS_PRED'})
            formatted_results=formatted_results[['Item_No', 'Current Long Text', 'CLASS_PRED', 'CHAR_SEQ_NO',  'CHAR', 'CHAR VALUES','STAND CHAR VALUES']]
            #print(formatted_results)
            formatted_results[['CHAR VALUES','STAND CHAR VALUES']]=formatted_results.apply(lambda x: get_missing_data(x),axis=1)
            
            st.session_state['cleansed_data']=formatted_results.copy()
        
        if ('cleansed_data' in st.session_state) and st.button("Show Results"):
            try:
                formatted_results1=post_process(st.session_state['cleansed_data'])
                fillrate_df=get_fill_rate_details(formatted_results1)
                cleanse_data_status=True
            except:
                st.write("Invalid Class or Text")
    with results_side:
        st.markdown("<h4 style='text-align: left; color: grey;'>Cleansing Results:</h4>", unsafe_allow_html=True)
        if cleanse_data_status and formatted_results1.shape[0]:
            st.dataframe(formatted_results1.style.map(review_fill_color, subset=['REVIEW']),hide_index=True)
            
        st.markdown("<h4 style='text-align: left; color: grey;'>Short Text:</h4>", unsafe_allow_html=True)
        if cleanse_data_status and formatted_results1.shape[0]:
            cleaned_std_data_dict={row['CHAR']:row['STAND CHAR VALUES'] for ind,row in formatted_results1.iterrows() if row['CHAR']!='ADDITIONAL_DETAIL'}
            st_generated=st_text_generate(cleaned_std_data_dict, st.session_state['s_class'])
            st.dataframe(pd.DataFrame([(12345,st.session_state['s_text'],st.session_state['s_class'],st_generated)],columns=['Item_No','Long Text','CLASS_PRED','ST GENERATED']),hide_index=True)
        
        st.markdown("<h4 style='text-align: left; color: grey;'>Fill Rate:</h4>", unsafe_allow_html=True)
        if cleanse_data_status and fillrate_df.shape[0]:
            st.dataframe(fillrate_df.style.map(fill_rate_color, subset=['FILL_RATE']),hide_index=True)
        
    
if option=='Bulk Material':
    uploaded_file=st.file_uploader("Upload Input File",type=['xlsx','xls','csv'])
    
    if uploaded_file:
        file_name=uploaded_file.name
        file_type=file_name.split(".")[-1]
        print("file_type", file_type)
        print("file_name", file_name)
        
        if file_type=='csv':
            test_data=pd.read_csv(os.path.join(INPUT_FOLDER, file_name))
        else:
            test_data=pd.read_excel(os.path.join(INPUT_FOLDER, file_name),"INPUT_DATA")
            
        test_data=test_data[['Item_No','long_text','short_text','char_data']]
            
    if uploaded_file is not None and st.button("Show Data"):
        st.dataframe(test_data,width=1700,height=700)
    
    if uploaded_file is not None and st.button("Get Classes"):
        test_data['LONG TEXT']=test_data.apply(lambda x: f'{x["long_text"]} ; {x["short_text"]}' if x['long_text']!='NOT AVAILABLE' else f'{x["short_text"]} ; {x["char_data"]}',axis=1)
        
        test_data[['LANG','CLASS_PRED','Confidence_Score']]=test_data['LONG TEXT'].apply(get_class)
        #test_data.to_csv(os.path.join(RESULTS_PATH,"classification_results.csv"),index=False)
        test_data=test_data.drop(columns=['LONG TEXT'])
      
        with st.container(border=True):
            try:
                st.markdown("<h5 style='text-align: center; color: black;'>Class Prediction Distribusion</h5>", unsafe_allow_html=True)
                chart_data=pd.DataFrame([(k,v) for k,v in dict(test_data['CLASS_PRED'].value_counts()).items()],columns=["CLASS PRED","COUNT"])
                chart=alt.Chart(chart_data).mark_bar().encode(
                    x="CLASS PRED:O",
                    y='COUNT:Q'
                ).properties(height=500,width=1200)
                st.altair_chart(chart)
            except:
                pass
        
        st.markdown("<h4 style='text-align: left; color: black;'>Class Prediction Results:</h4>", unsafe_allow_html=True)
        st.dataframe(test_data,width=1700,height=700)
        st.session_state['pred_class_data']=test_data
        
    if 'pred_class_data' in st.session_state and st.button("Cleanse Material"):
        prg = st.progress(0)
        sample_input=st.session_state['pred_class_data']
        sample_input=sample_input[(sample_input['Confidence_Score']>=0.50) & (sample_input['LANG']=='ENGLISH')].copy()
        if sample_row_size<=sample_input.shape[0]:
            sample_input=sample_input.sample(n=sample_row_size).copy()
        rowcount=sample_input.shape[0]
        formatted_results_all=[]
        count=0.0
        for ind,row in sample_input.iterrows():
            count=count+1
            try:
                custom_functions=get_custom_function(row['CLASS_PRED'])
                long_text_cleaned=None
                long_text_llm_resp={}
                
                if row['long_text']!='NOT AVAILABLE':
                    long_text_cleaned=clean_text(str(row['long_text']))
                    long_text_cleaned=long_text_cleaned.replace('*',' ')
                    long_text_llm_resp=get_llm_response(long_text_cleaned,custom_functions, row['CLASS_PRED'])
                elif row['char_data']:
                    long_text_cleaned=clean_text(str(row['char_data']))
                    long_text_cleaned=long_text_cleaned.replace('*',' ')
                    long_text_llm_resp=get_llm_response(long_text_cleaned,custom_functions, row['CLASS_PRED'])
                formatted_results=format_results(row['Item_No'],long_text_cleaned,row['CLASS_PRED'],long_text_llm_resp)
                formatted_results_all.append(formatted_results)
                per_completed=int((count/rowcount)*100)
                prg.progress(per_completed, text=f'{per_completed}%')
            except Exception as err:
                print(err)
                print(f"Not Cleansed:{row['Item_No']}")
                formatted_results=format_results(row['Item_No'],long_text_cleaned,row['CLASS_PRED'],{})
                formatted_results_all.append(formatted_results)
        formatted_results_df=pd.concat(formatted_results_all)
        st.session_state['bulk_cleanse_result']=formatted_results_df
    if 'bulk_cleanse_result' in st.session_state and st.button("Show Results"):
        pred_class_data=st.session_state['pred_class_data']
        class_results=pred_class_data.rename(columns={"long_text":"Current Long Text","Confidence_Score":"PRED_CLASS_CONFIDENCE"})
        bulk_cleanse_results=st.session_state['bulk_cleanse_result']
        merged_results=pd.merge(bulk_cleanse_results,class_results,left_on=['Item_No'],right_on=['Item_No'],how='left')
        merged_results=merged_results[['Item_No', 'Current Long Text', 'CLASS_PRED','PRED_CLASS_CONFIDENCE', 'CHAR_SEQ_NO',  'CHAR', 'CHAR VALUES','STAND CHAR VALUES']]
        merged_results[['CHAR VALUES','STAND CHAR VALUES']]=merged_results.apply(lambda x: get_missing_data(x),axis=1)
        post_process_df=post_process(merged_results)
        
        bulk_fill_rate_df=get_fill_rate_details(post_process_df)
        with st.container(border=True):
            st.markdown("<h4 style='text-align: left; color: black;'>Fill Rate Report</h4>", unsafe_allow_html=True)
            table, plot = st.columns(2)
            with table:
                st.table(bulk_fill_rate_df.style.map(fill_rate_color,subset=['FILL_RATE']))
                st.image(ledger_img,width=150)
            with plot:
                try:
                    pie_fig=get_fill_rate_chart(bulk_fill_rate_df)
                    #st.pyplot(pie_fig)
                    st.altair_chart(pie_fig)
                except:
                    pass
        
        st.markdown("<h4 style='text-align: left; color: black;'>Cleansing Results:</h4>", unsafe_allow_html=True)
        st.dataframe(post_process_df.style.map(review_fill_color,subset=['REVIEW']),width=2000,height=700,hide_index=True)
        
        post_process_df_groups=post_process_df.groupby('Item_No')
        
        st_df_rows=[]
        for g,df in post_process_df_groups:
            new_row={}
            new_row['Item_No']=g
            new_row['Current Long Text']=df['Current Long Text'].unique().tolist()[0]
            new_row['CLASS_PRED']=df['CLASS_PRED'].tolist()[0]
            cleaned_std_data_dict={row['CHAR']:row['STAND CHAR VALUES'] for ind,row in df.iterrows() if row['CHAR']!='ADDITIONAL_DETAIL'}
            st_generated=st_text_generate(cleaned_std_data_dict, new_row.get('CLASS_PRED'))
            new_row['Short Text Generated']=st_generated
            st_df_rows.append(new_row)
            
        st.markdown("<h4 style='text-align: left; color: black;'>Short Text Results:</h4>", unsafe_allow_html=True)
        st.dataframe(pd.DataFrame(st_df_rows),hide_index=True)
            
        
        
        
        
        